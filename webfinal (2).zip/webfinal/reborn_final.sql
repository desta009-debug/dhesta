-- ============================================
-- SQL UPDATE - REBORN GARAGE
-- Kategori & Password Update Enhancement
-- ============================================

-- 1. TAMBAH KOLOM DESKRIPSI DI TABEL KATEGORI (OPSIONAL)
ALTER TABLE kategori 
ADD COLUMN IF NOT EXISTS deskripsi TEXT DEFAULT NULL 
AFTER nama_kategori;

-- 2. TAMBAH KOLOM CREATED_AT & UPDATED_AT DI TABEL KATEGORI
ALTER TABLE kategori 
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- 3. TAMBAH INDEX UNTUK PERFORMA QUERY
ALTER TABLE kategori 
ADD INDEX idx_nama_kategori (nama_kategori);

-- 4. TAMBAH UNIQUE CONSTRAINT UNTUK NAMA KATEGORI (MENCEGAH DUPLIKAT)
ALTER TABLE kategori 
ADD UNIQUE KEY unique_nama_kategori (nama_kategori);

-- 5. VERIFIKASI STRUKTUR TABEL KATEGORI
DESCRIBE kategori;

-- ============================================
-- STRUKTUR LENGKAP TABEL KATEGORI SETELAH UPDATE:
-- ============================================
-- id_kategori (INT PRIMARY KEY AUTO_INCREMENT)
-- nama_kategori (VARCHAR UNIQUE)
-- deskripsi (TEXT) ← BARU (OPSIONAL)
-- created_at (TIMESTAMP) ← BARU
-- updated_at (TIMESTAMP) ← BARU
-- ============================================

-- 6. INSERT SAMPLE DATA KATEGORI (JIKA BELUM ADA)
INSERT IGNORE INTO kategori (nama_kategori, deskripsi) VALUES
('Oli', 'Pelumas mesin kendaraan'),
('Ban', 'Ban dan velg kendaraan'),
('Lampu', 'Sistem pencahayaan kendaraan'),
('Spion', 'Kaca spion dan aksesoris'),
('Rem', 'Sistem pengereman kendaraan'),
('Filter', 'Filter oli, udara, dan bahan bakar'),
('Aki', 'Baterai dan akumulator'),
('Kampas Rem', 'Kampas rem cakram dan tromol'),
('Bearing', 'Bearing dan komponen rotasi'),
('Rantai', 'Rantai dan gear set');

-- 7. QUERY UNTUK CEK KATEGORI DENGAN JUMLAH PRODUK
SELECT 
    k.id_kategori,
    k.nama_kategori,
    k.deskripsi,
    COUNT(p.id_produk) as total_produk,
    k.created_at,
    k.updated_at
FROM kategori k
LEFT JOIN produk p ON k.id_kategori = p.id_kategori
GROUP BY k.id_kategori
ORDER BY k.nama_kategori ASC;

-- 8. QUERY UNTUK CEK KATEGORI YANG BELUM MEMILIKI PRODUK
SELECT 
    k.id_kategori,
    k.nama_kategori,
    k.deskripsi
FROM kategori k
LEFT JOIN produk p ON k.id_kategori = p.id_kategori
WHERE p.id_produk IS NULL
ORDER BY k.nama_kategori ASC;

-- 9. QUERY UNTUK CEK KATEGORI DENGAN PRODUK TERBANYAK
SELECT 
    k.nama_kategori,
    COUNT(p.id_produk) as jumlah_produk,
    SUM(p.stok) as total_stok,
    SUM(p.harga * p.stok) as nilai_inventory
FROM kategori k
INNER JOIN produk p ON k.id_kategori = p.id_kategori
GROUP BY k.id_kategori
ORDER BY jumlah_produk DESC
LIMIT 10;

-- ============================================
-- PASSWORD UPDATE UNTUK USERS
-- ============================================

-- 10. TAMBAH KOLOM PASSWORD_UPDATED_AT DI TABEL USERS
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS password_updated_at TIMESTAMP NULL DEFAULT NULL 
AFTER password;

-- 11. TAMBAH KOLOM LAST_LOGIN DI TABEL USERS
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS last_login TIMESTAMP NULL DEFAULT NULL;

-- 12. VERIFIKASI STRUKTUR TABEL USERS
DESCRIBE users;

-- ============================================
-- STRUKTUR LENGKAP TABEL USERS SETELAH UPDATE:
-- ============================================
-- id_user (INT PRIMARY KEY AUTO_INCREMENT)
-- nama (VARCHAR)
-- email (VARCHAR UNIQUE)
-- password (VARCHAR)
-- password_updated_at (TIMESTAMP) ← BARU
-- last_login (TIMESTAMP) ← BARU
-- role (ENUM: 'staff', 'pembeli')
-- ============================================

-- 13. UPDATE PASSWORD_UPDATED_AT UNTUK USER YANG SUDAH ADA
UPDATE users 
SET password_updated_at = CURRENT_TIMESTAMP 
WHERE password_updated_at IS NULL;

-- 14. QUERY UNTUK CEK USER YANG BELUM UPDATE PASSWORD DALAM 90 HARI
SELECT 
    id_user,
    nama,
    email,
    role,
    password_updated_at,
    DATEDIFF(CURRENT_TIMESTAMP, password_updated_at) as hari_sejak_update
FROM users
WHERE password_updated_at IS NOT NULL
  AND DATEDIFF(CURRENT_TIMESTAMP, password_updated_at) > 90
ORDER BY password_updated_at ASC;

-- 15. QUERY UNTUK CEK AKTIVITAS LOGIN USER
SELECT 
    id_user,
    nama,
    email,
    role,
    last_login,
    CASE 
        WHEN last_login IS NULL THEN 'Belum Pernah Login'
        WHEN DATEDIFF(CURRENT_TIMESTAMP, last_login) = 0 THEN 'Hari Ini'
        WHEN DATEDIFF(CURRENT_TIMESTAMP, last_login) = 1 THEN 'Kemarin'
        WHEN DATEDIFF(CURRENT_TIMESTAMP, last_login) <= 7 THEN 'Minggu Ini'
        WHEN DATEDIFF(CURRENT_TIMESTAMP, last_login) <= 30 THEN 'Bulan Ini'
        ELSE 'Lebih dari 30 Hari'
    END as status_login
FROM users
ORDER BY last_login DESC;

-- ============================================
-- CLEANUP & MAINTENANCE QUERIES
-- ============================================

-- 16. HAPUS KATEGORI YANG TIDAK MEMILIKI PRODUK (HATI-HATI!)
-- DELETE FROM kategori 
-- WHERE id_kategori NOT IN (SELECT DISTINCT id_kategori FROM produk WHERE id_kategori IS NOT NULL);

-- 17. RESET AUTO INCREMENT KATEGORI (JIKA DIPERLUKAN)
-- ALTER TABLE kategori AUTO_INCREMENT = 1;

-- 18. BACKUP TABEL KATEGORI SEBELUM PERUBAHAN BESAR
CREATE TABLE IF NOT EXISTS kategori_backup AS 
SELECT * FROM kategori;

-- 19. CEK INTEGRITAS DATA KATEGORI
SELECT 
    'Total Kategori' as info,
    COUNT(*) as jumlah
FROM kategori
UNION ALL
SELECT 
    'Kategori Aktif (Punya Produk)' as info,
    COUNT(DISTINCT k.id_kategori) as jumlah
FROM kategori k
INNER JOIN produk p ON k.id_kategori = p.id_kategori
UNION ALL
SELECT 
    'Kategori Tidak Aktif (Tidak Punya Produk)' as info,
    COUNT(*) as jumlah
FROM kategori k
LEFT JOIN produk p ON k.id_kategori = p.id_kategori
WHERE p.id_produk IS NULL;
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS foto_profil VARCHAR(255) DEFAULT NULL 
AFTER password;

-- ============================================
-- SELESAI - SQL UPDATE BERHASIL!
-- ============================================

-- Catatan:
-- 1. Jalankan query ini satu per satu atau dalam batch
-- 2. Backup database sebelum menjalankan perubahan struktur
-- 3. Test di development environment terlebih dahulu
-- 4. Pastikan semua foreign key constraint tidak bermasalah