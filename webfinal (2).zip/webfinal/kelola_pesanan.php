<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Admin Staff';

$success = "";
$error = "";

// Handle accept order (pending -> processing)
if (isset($_POST['accept_order'])) {
    $id_order = (int)$_POST['id_order'];
    
    $query = "UPDATE orders SET status = 'processing' WHERE id_order = $id_order AND status = 'pending'";
    if (mysqli_query($conn, $query)) {
        $success = "Pesanan berhasil diterima dan sedang diproses!";
    } else {
        $error = "Gagal menerima pesanan: " . mysqli_error($conn);
    }
}

// Handle status update with automatic barang_keluar integration
if (isset($_POST['update_status'])) {
    $id_order = (int)$_POST['id_order'];
    $new_status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Jika status berubah menjadi 'completed', catat barang keluar dan update stok
        if ($new_status == 'completed') {
            // Ambil data order items
            $items_query = "
                SELECT oi.id_produk, oi.jumlah, p.nama_produk, p.stok
                FROM order_items oi 
                JOIN produk p ON oi.id_produk = p.id_produk
                WHERE oi.id_order = $id_order
            ";
            $items_result = mysqli_query($conn, $items_query);
            
            while ($item = mysqli_fetch_assoc($items_result)) {
                $id_produk = $item['id_produk'];
                $jumlah = $item['jumlah'];
                $stok_tersedia = $item['stok'];
                
                // Cek apakah stok mencukupi
                if ($stok_tersedia < $jumlah) {
                    throw new Exception("Stok {$item['nama_produk']} tidak mencukupi! Tersedia: {$stok_tersedia}, Dibutuhkan: {$jumlah}");
                }
                
                $tanggal = date('Y-m-d');
                $tujuan = "Penjualan Online";
                $keterangan = "Pesanan #" . $id_order;
                
                // Insert ke tabel barang_keluar
                $insert_keluar = "
                    INSERT INTO barang_keluar 
                    (id_produk, jumlah, tanggal, tujuan, keterangan) 
                    VALUES 
                    ($id_produk, $jumlah, '$tanggal', '$tujuan', '$keterangan')
                ";
                
                if (!mysqli_query($conn, $insert_keluar)) {
                    throw new Exception("Gagal mencatat barang keluar: " . mysqli_error($conn));
                }
                
                // Update stok produk (kurangi stok)
                $update_stok = "
                    UPDATE produk 
                    SET stok = stok - $jumlah 
                    WHERE id_produk = $id_produk
                ";
                
                if (!mysqli_query($conn, $update_stok)) {
                    throw new Exception("Gagal update stok produk: " . mysqli_error($conn));
                }
            }
        }
        
        // Update status order
        $query = "UPDATE orders SET status = '$new_status' WHERE id_order = $id_order";
        if (!mysqli_query($conn, $query)) {
            throw new Exception("Gagal memperbarui status: " . mysqli_error($conn));
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        $success = "Status pesanan berhasil diperbarui!";
        if ($new_status == 'completed') {
            $success .= " Barang telah tercatat keluar dari inventory dan stok diperbarui.";
        }
        
    } catch (Exception $e) {
        // Rollback on error
        mysqli_rollback($conn);
        $error = $e->getMessage();
    }
}

// Handle delete order
if (isset($_POST['delete_order'])) {
    $id_order = (int)$_POST['id_order'];
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Delete order items first (foreign key constraint)
        if (!mysqli_query($conn, "DELETE FROM order_items WHERE id_order = $id_order")) {
            throw new Exception("Gagal menghapus item pesanan: " . mysqli_error($conn));
        }
        
        // Then delete the order
        $query = "DELETE FROM orders WHERE id_order = $id_order";
        if (!mysqli_query($conn, $query)) {
            throw new Exception("Gagal menghapus pesanan: " . mysqli_error($conn));
        }
        
        // Commit transaction
        mysqli_commit($conn);
        $success = "Pesanan berhasil dihapus!";
        
    } catch (Exception $e) {
        // Rollback on error
        mysqli_rollback($conn);
        $error = $e->getMessage();
    }
}

// Get filter
$filter_status = isset($_GET['status']) ? $_GET['status'] : 'all';

// Get all orders with customer info
$query = "
    SELECT o.*, u.nama, u.email 
    FROM orders o 
    LEFT JOIN users u ON o.id_user = u.id_user
";

if ($filter_status != 'all') {
    $query .= " WHERE o.status = '" . mysqli_real_escape_string($conn, $filter_status) . "'";
}

$query .= " ORDER BY o.tanggal_order DESC";
$orders_result = mysqli_query($conn, $query);

// Calculate statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
        SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders,
        SUM(CASE WHEN status = 'completed' THEN total_harga ELSE 0 END) as total_revenue
    FROM orders
";
$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Pesanan - Reborn Garage</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.sidebar.small .logo-image {
    width: 50px;
    height: 50px;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== PAGE HEADER ========== */
.page-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.page-header h1 {
    font-size: 36px;
    margin-bottom: 8px;
    font-weight: 700;
}

.page-header p {
    font-size: 16px;
    opacity: 0.9;
}

/* ========== ALERT ========== */
.alert {
    padding: 16px 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.alert-success {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
    border-left: 4px solid var(--success);
}

.alert-error {
    background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%);
    color: #b71c1c;
    border-left: 4px solid var(--danger);
}

/* ========== STATS CARDS ========== */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.12);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
}

.stat-icon.info { background: linear-gradient(135deg, #1e88e5, #42a5f5); }
.stat-icon.warning { background: linear-gradient(135deg, #ff9800, #fb8c00); }
.stat-icon.success { background: linear-gradient(135deg, #4caf50, #66bb6a); }
.stat-icon.danger { background: linear-gradient(135deg, #f44336, #ef5350); }
.stat-icon.purple { background: linear-gradient(135deg, #9c27b0, #ba68c8); }
.stat-icon.blue { background: linear-gradient(135deg, #2196f3, #64b5f6); }

.stat-details h3 {
    font-size: 14px;
    color: #666;
    margin-bottom: 5px;
    font-weight: 500;
}

.stat-details .stat-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary);
}

.stat-details .stat-sub {
    font-size: 12px;
    color: var(--accent);
    margin-top: 3px;
    font-weight: 600;
}

/* ========== FILTER SECTION ========== */
.filter-section {
    background: white;
    padding: 25px;
    border-radius: 16px;
    margin-bottom: 30px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.filter-buttons {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 12px 24px;
    border: 2px solid #e0e0e0;
    background: white;
    color: #666;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.filter-btn:hover {
    border-color: var(--accent);
    color: var(--accent);
    transform: translateY(-2px);
}

.filter-btn.active {
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    border-color: var(--accent);
}

/* ========== TABLE SECTION ========== */
.table-section {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.table-header h2 {
    font-size: 24px;
    color: var(--primary);
    font-weight: 700;
}

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background: var(--primary);
    color: white;
}

th {
    padding: 15px 12px;
    text-align: left;
    font-weight: 700;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

td {
    padding: 15px 12px;
    border-bottom: 1px solid #f0f0f0;
    color: #333;
    font-size: 14px;
}

tbody tr {
    transition: all 0.2s;
}

tbody tr:hover {
    background: #f9f9f9;
}

/* ========== STATUS BADGES ========== */
.status-badge {
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 700;
    display: inline-block;
    text-transform: uppercase;
}

.status-pending {
    background: linear-gradient(135deg, #fff3e0, #ffe0b2);
    color: #e65100;
}

.status-processing {
    background: linear-gradient(135deg, #e3f2fd, #bbdefb);
    color: #0d47a1;
}

.status-completed {
    background: linear-gradient(135deg, #c8e6c9, #a5d6a7);
    color: #1b5e20;
}

.status-cancelled {
    background: linear-gradient(135deg, #ffcdd2, #ef9a9a);
    color: #b71c1c;
}

/* ========== PAYMENT BADGES ========== */
.payment-badge {
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
    background: linear-gradient(135deg, #e3f2fd, #bbdefb);
    color: #0d47a1;
}

/* ========== ACTION BUTTONS ========== */
.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn {
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-accept {
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
}

.btn-accept:hover {
    background: linear-gradient(135deg, #2e7d32, #388e3c);
    transform: translateY(-2px);
}

.btn-detail {
    background: linear-gradient(135deg, var(--info), #42a5f5);
    color: white;
}

.btn-detail:hover {
    background: linear-gradient(135deg, #1565c0, #1976d2);
    transform: translateY(-2px);
}

.btn-delete {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c62828, #d32f2f);
    transform: translateY(-2px);
}

/* ========== MODAL ========== */
.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.6);
    animation: fadeIn 0.3s;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.modal-content {
    background: white;
    margin: 50px auto;
    padding: 40px;
    border-radius: 16px;
    max-width: 800px;
    max-height: 80vh;
    overflow-y: auto;
    animation: slideUp 0.3s;
}

@keyframes slideUp {
    from {
        transform: translateY(50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
}

.modal-header h2 {
    color: var(--primary);
    font-size: 24px;
}

.close {
    font-size: 32px;
    font-weight: 700;
    color: #999;
    cursor: pointer;
    transition: all 0.3s;
}

.close:hover {
    color: var(--danger);
    transform: scale(1.2);
}

.order-info {
    margin-bottom: 25px;
}

.info-row {
    display: flex;
    padding: 12px 0;
    border-bottom: 1px solid #f5f5f5;
}

.info-label {
    font-weight: 600;
    color: #666;
    width: 180px;
}

.info-value {
    color: var(--primary);
}

.items-table {
    margin-top: 25px;
}

.items-table h3 {
    margin-bottom: 15px;
    color: var(--primary);
}

.form-group {
    margin-top: 25px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 10px;
    color: var(--primary);
}

.form-group select {
    width: 100%;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
}

.modal-actions {
    margin-top: 25px;
    display: flex;
    gap: 15px;
    justify-content: flex-end;
}

.btn-primary {
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    padding: 12px 30px;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #2e7d32, #388e3c);
}

.btn-secondary {
    background: #e0e0e0;
    color: #333;
    padding: 12px 30px;
}

.btn-secondary:hover {
    background: #d0d0d0;
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-icon {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-state h3 {
    font-size: 22px;
    color: var(--primary);
    margin-bottom: 8px;
}

.empty-state p {
    color: #666;
    font-size: 14px;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header h1 {
        font-size: 28px;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .filter-buttons {
        flex-direction: column;
    }
    
    .filter-btn {
        width: 100%;
    }
    
    .table-wrapper {
        overflow-x: scroll;
    }
    
    table {
        min-width: 1000px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .modal-content {
        margin: 20px;
        padding: 25px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👤</span>
            <span class="badge-text"><?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_staff.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="data_produk.php">
            <span class="icon">📦</span>
            <span>Kelola Produk</span>
        </a>
        <a href="kategori.php">
            <span class="icon">🏷️</span>
            <span>Kategori</span>
        </a>
        <a href="supplier.php">
            <span class="icon">🏭</span>
            <span>Supplier</span>
        </a>
        <a href="barang_masuk.php">
            <span class="icon">📥</span>
            <span>Barang Masuk</span>
        </a>
        <a href="barang_keluar.php">
            <span class="icon">📤</span>
            <span>Barang Keluar</span>
        </a>
        <a href="kelola_pesanan.php" class="active">
            <span class="icon">📋</span>
            <span>Kelola Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h1>📋 Kelola Pesanan</h1>
        <p>Monitor dan kelola semua pesanan pelanggan dengan sistem terintegrasi</p>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <span>✅</span>
            <span><?= $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-error">
            <span>❌</span>
            <span><?= $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- STATISTICS CARDS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon info">📋</div>
            <div class="stat-details">
                <h3>Total Pesanan</h3>
                <div class="stat-value"><?= number_format($stats['total_orders'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon warning">⏳</div>
            <div class="stat-details">
                <h3>Menunggu</h3>
                <div class="stat-value"><?= number_format($stats['pending_orders'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon blue">🔄</div>
            <div class="stat-details">
                <h3>Diproses</h3>
                <div class="stat-value"><?= number_format($stats['processing_orders'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon success">✓</div>
            <div class="stat-details">
                <h3>Selesai</h3>
                <div class="stat-value"><?= number_format($stats['completed_orders'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon danger">✖</div>
            <div class="stat-details">
                <h3>Dibatalkan</h3>
                <div class="stat-value"><?= number_format($stats['cancelled_orders'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon purple">💰</div>
            <div class="stat-details">
                <h3>Total Pendapatan</h3>
                <div class="stat-value">Rp <?= number_format($stats['total_revenue'] ?? 0, 0, ',', '.') ?></div>
                <div class="stat-sub">Dari pesanan selesai</div>
            </div>
        </div>
    </div>

    <!-- FILTER SECTION -->
    <div class="filter-section">
        <div class="filter-buttons">
            <a href="?status=all" class="filter-btn <?= $filter_status == 'all' ? 'active' : '' ?>">
                📊 Semua Pesanan
            </a>
            <a href="?status=pending" class="filter-btn <?= $filter_status == 'pending' ? 'active' : '' ?>">
                ⏳ Menunggu
            </a>
            <a href="?status=processing" class="filter-btn <?= $filter_status == 'processing' ? 'active' : '' ?>">
                🔄 Diproses
            </a>
            <a href="?status=completed" class="filter-btn <?= $filter_status == 'completed' ? 'active' : '' ?>">
                ✓ Selesai
            </a>
            <a href="?status=cancelled" class="filter-btn <?= $filter_status == 'cancelled' ? 'active' : '' ?>">
                ✖ Dibatalkan
            </a>
        </div>
    </div>

    <!-- TABLE SECTION -->
    <div class="table-section">
        <div class="table-header">
            <h2>📋 Daftar Pesanan</h2>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th style="width: 80px;">ID Order</th>
                        <th>Pelanggan</th>
                        <th>Email</th>
                        <th>Total Harga</th>
                        <th>Pembayaran</th>
                        <th>Status</th>
                        <th style="width: 140px;">Tanggal</th>
                        <th style="width: 250px; text-align: center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($orders_result && mysqli_num_rows($orders_result) > 0): ?>
                        <?php while ($order = mysqli_fetch_assoc($orders_result)): ?>
                            <tr>
                                <td><strong>#<?= $order['id_order'] ?></strong></td>
                                <td><?= htmlspecialchars($order['nama'] ?? 'Guest') ?></td>
                                <td><?= htmlspecialchars($order['email'] ?? '-') ?></td>
                                <td><strong>Rp <?= number_format($order['total_harga'], 0, ',', '.') ?></strong></td>
                                <td>
                                    <span class="payment-badge">
                                        <?php
                                        $payment_labels = [
                                            'cash' => '💵 Cash',
                                            'transfer_bank' => '🏦 Transfer',
                                            'e_wallet' => '📱 E-Wallet',
                                            'cicilan' => '💳 Cicilan'
                                        ];
                                        echo $payment_labels[$order['metode_pembayaran']] ?? $order['metode_pembayaran'];
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $status_class = 'status-' . $order['status'];
                                    $status_labels = [
                                        'pending' => '⏳ Menunggu',
                                        'processing' => '🔄 Diproses',
                                        'completed' => '✓ Selesai',
                                        'cancelled' => '✖ Dibatalkan'
                                    ];
                                    ?>
                                    <span class="status-badge <?= $status_class ?>">
                                        <?= $status_labels[$order['status']] ?? $order['status'] ?>
                                    </span>
                                </td>
                                <td><?= date('d M Y H:i', strtotime($order['tanggal_order'])) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($order['status'] == 'pending'): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Terima pesanan ini?')">
                                                <input type="hidden" name="id_order" value="<?= $order['id_order'] ?>">
                                                <button type="submit" name="accept_order" class="btn btn-accept">
                                                    ✓ Terima
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <button class="btn btn-detail" onclick="viewOrder(<?= $order['id_order'] ?>)">
                                            👁️ Detail
                                        </button>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus pesanan ini?')">
                                            <input type="hidden" name="id_order" value="<?= $order['id_order'] ?>">
                                            <button type="submit" name="delete_order" class="btn btn-delete">
                                                🗑️ Hapus
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">
                                <div class="empty-state">
                                    <div class="empty-icon">📭</div>
                                    <h3>Tidak Ada Pesanan</h3>
                                    <p>Belum ada pesanan yang masuk</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- MODAL DETAIL ORDER -->
<div id="orderModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>📋 Detail Pesanan</h2>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <div id="orderDetails">
            <p style="text-align: center; padding: 40px; color: #999;">Memuat data...</p>
        </div>
    </div>
</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

function viewOrder(orderId) {
    const modal = document.getElementById('orderModal');
    const detailsDiv = document.getElementById('orderDetails');
    
    modal.style.display = 'block';
    detailsDiv.innerHTML = '<p style="text-align: center; padding: 40px; color: #999;">Memuat data...</p>';
    
    // Fetch order details via AJAX
    fetch('get_order_details.php?id=' + orderId)
        .then(response => response.text())
        .then(data => {
            detailsDiv.innerHTML = data;
        })
        .catch(error => {
            detailsDiv.innerHTML = '<p style="color: red; text-align: center;">Gagal memuat data</p>';
        });
}

function closeModal() {
    document.getElementById('orderModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('orderModal');
    if (event.target == modal) {
        closeModal();
    }
}

// Auto-hide success/error messages
<?php if ($success || $error): ?>
setTimeout(() => {
    const alert = document.querySelector('.alert');
    if (alert) {
        alert.style.transition = 'all 0.3s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }
}, 5000);
<?php endif; ?>

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s';
        document.body.style.opacity = '1';
    }, 100);
});
</script>

</body>
</html>