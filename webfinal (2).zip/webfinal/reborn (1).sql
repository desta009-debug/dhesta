-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2026 at 10:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reborn`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang_keluar`
--

CREATE TABLE `barang_keluar` (
  `id_barang_keluar` int(11) NOT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `id_kategori` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `tujuan` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang_keluar`
--

INSERT INTO `barang_keluar` (`id_barang_keluar`, `id_produk`, `id_kategori`, `tanggal`, `jumlah`, `tujuan`, `keterangan`) VALUES
(101, 311, 1, '2025-12-02', 20, 'INDRAMAYU', 'PENJUALAN'),
(102, 411, 2, '2025-12-02', 80, 'PALEMBANG', 'PENJUALAN'),
(103, 511, 3, '2025-12-03', 90, 'INDRAMAYU', 'PENJUALAN'),
(104, 711, 4, '2025-12-06', 33, 'PADANG', 'PENJUALAN'),
(105, 911, 5, '2025-12-07', 10, 'LAMPUNG', 'PENJUALAN'),
(106, 811, 6, '2025-12-11', 20, 'PADANG', 'PENJUALAN'),
(107, 611, 7, '2025-12-08', 60, 'CIKAMPEK', 'PENJUALAN'),
(108, 214, 8, '2025-12-14', 10, 'PADANG', 'PENJUALAN'),
(109, 200, 9, '2025-12-15', 20, 'DEPOK', 'PENJUALAN'),
(110, 1011, 10, '2025-12-13', 12, 'LAMPUNG', 'PENJUALAN'),
(111, 201, 11, '2025-12-15', 18, 'CIKARANG', 'PENJUALAN'),
(112, 204, 12, '2025-12-16', 25, 'JOGJA', 'PENJUALAN'),
(113, 205, 13, '2025-12-17', 52, 'PACITAN', 'PENJUALAN'),
(114, 206, 14, '2025-12-18', 32, 'MAGETAN', 'PENJUALAN'),
(115, 207, 15, '2025-12-18', 17, 'MAGELANG', 'PENJUALAN'),
(116, 208, 16, '2025-12-19', 31, 'DIENG', 'PENJUALAN'),
(118, 209, 17, '2025-12-20', 29, 'PANGANDARAN', 'PENJUALAN'),
(119, 210, 18, '2025-12-21', 43, 'GARUT', 'PENJUALAN'),
(120, 211, 19, '2025-12-22', 41, 'CIKIJING', 'PENJUALAN'),
(121, 212, 20, '2025-12-23', 62, 'SEMARANG', 'PENJUALAN'),
(122, 213, 21, '2025-12-24', 72, 'KEBUMEN', 'PEMBELIAN'),
(123, 213, 22, '2025-12-25', 27, 'CILACAP', 'PEMBELIAN'),
(124, 203, 23, '2025-12-26', 39, 'BANJAR', 'PEMBELIAN'),
(125, 215, 24, '2025-12-27', 49, 'INDRAMAYU', 'PEMBELIAN'),
(126, 218, 25, '2025-12-28', 58, 'PLERED', 'PEMBELIAN'),
(127, 200, 0, '2025-12-29', 31, 'CIANJUR', 'PEMBELIAN'),
(128, 201, 0, '2025-12-30', 11, 'TASIKMALAYA', 'PEMBELIAN'),
(129, 203, 0, '2025-12-30', 22, 'SUBANG', 'PEMBELIAN'),
(130, 205, 0, '2025-12-31', 44, 'PAMANUKAN', 'PEMBELIAN');

-- --------------------------------------------------------

--
-- Table structure for table `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `id_barang_masuk` int(11) NOT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `id_supplier` int(11) DEFAULT NULL,
  `stok` int(11) NOT NULL,
  `produk` varchar(50) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `supplier` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga_beli` int(11) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `gambar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang_masuk`
--

INSERT INTO `barang_masuk` (`id_barang_masuk`, `id_produk`, `id_supplier`, `stok`, `produk`, `id_kategori`, `supplier`, `tanggal`, `jumlah`, `harga_beli`, `keterangan`, `gambar`) VALUES
(101, 311, 1, 40, 'SPION VND', 1, 'PT.ASTRA', '2025-12-01', 90, 70, 'SUPPLY', ''),
(102, 411, 3, 40, 'oli shel', 2, 'PT AHM', '2025-12-02', 10, 70, 'SUPPLY', ''),
(103, 511, 2, 50, 'BAN FEDERAL', 3, 'PT ASTRA', '2025-12-03', 50, 50, 'SUPPLY', ''),
(104, 611, 4, 30, 'MASTER REM RCB', 4, 'PT  KURNIA MOTOR', '2025-12-04', 90, 100, 'SUPPLY', ''),
(105, 711, 2, 10, 'SEHER VARIO OLD', 5, 'PT AHASS', '2025-12-05', 80, 50, 'SUPPLY', ''),
(106, 811, 3, 40, 'KNALPOT TZM', 6, 'PT SUMBER MEKANIK', '2025-12-06', 70, 70, 'SUPPLY', ''),
(107, 911, 4, 60, 'PULY HONDA', 7, 'PT  ASTRA', '2025-12-07', 90, 50, 'SUPPLY', ''),
(108, 1011, 5, 90, 'HANDGRIP BEAT', 8, 'PT AHASS', '2025-12-08', 80, 70, 'SUPPLY', ''),
(109, 311, 3, 40, 'LOLER BRT', 9, 'PT SRI  MENTARI NIAG', '2025-12-09', 100, 100, 'SUPPLY', ''),
(110, 411, 2, 50, 'KAPAS REM HONDA', 10, 'PT AHM', '2025-12-10', 60, 30, 'SUPPLY', ''),
(111, 511, 4, 80, 'LAMPU SEN YAMAHA', 11, 'PT TYTO MOTOR', '2025-12-11', 90, 80, 'SUPPLY', ''),
(112, 611, 5, 20, 'LAMPU DEPAN VARIO', 12, 'PT AHASS', '2025-12-12', 60, 90, 'SUPPLY', ''),
(113, 611, 5, 40, 'REFLEKTOR LAMPU HONDA', 13, 'PT AHM', '2025-12-13', 90, 100, '', ''),
(114, 711, 3, 40, 'LAMPU BELAKANG HONDA', 14, 'PT AHM', '2025-12-14', 50, 50, 'SUPPLY', ''),
(115, 811, 4, 40, 'REFLEKTOR LAMPU BELAKANG YAMAHA', 15, 'PT AHS', '2025-12-15', 90, 100, 'SUPPLY', ''),
(116, 811, 2, 50, 'TENSIONER HONDA', 16, 'PT KURNIA MOTOR', '2025-12-16', 80, 70, 'SUPPLY', ''),
(117, 911, 1, 60, 'LOLLER BRT', 17, 'PT TRI MENTARI NIAGA', '2025-12-17', 60, 70, 'SUPPLY', ''),
(118, 214, 4, 70, 'KALIPER HONDA', 18, 'PT AHASS', '2025-12-18', 40, 20, 'SUPPLY', ''),
(119, 200, 5, 45, 'BAUT BIASA MOTOR ', 19, 'PT AHM', '2025-12-19', 15, 40, 'SUPPLY', ''),
(120, 1011, 4, 50, 'BAUT TITAN YAMAHA', 20, 'PT YAMAHA', '2025-12-20', 70, 60, 'SUPPLY', ''),
(121, 214, 5, 30, 'SHOKBEKER HONDA', 21, 'PT AHM', '2025-12-21', 45, 100, 'SUPPLY', ''),
(122, 201, 5, 35, 'SPAKBOR MOTOR HONDA', 22, 'PT AHASS', '2025-12-22', 60, 80, 'SUPPLY', ''),
(123, 204, 4, 70, 'ECU YAMAHA', 23, 'PT YAMAHA', '2025-12-23', 20, 150, 'SUPPLY', ''),
(124, 205, 2, 50, 'KLAHER HONDA', 24, 'PT ARIDA HONDA', '2025-12-24', 20, 40, 'SUPPLY', ''),
(125, 206, 4, 20, 'BEARING MOTOR', 25, 'PT SUMBER MOTOR', '2025-12-25', 100, 150, 'SUPPLY', '');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'spion'),
(2, 'oli'),
(3, 'ban'),
(4, 'master rem'),
(5, 'seher'),
(6, 'knalpot'),
(7, 'puly'),
(8, 'handgrip'),
(9, 'roler'),
(10, 'kampas rem'),
(11, 'lampu sen'),
(12, 'lampu depan'),
(13, 'reflektor lampu'),
(14, 'lampu belakang'),
(15, 'reflektor lampu belakang'),
(16, 'tensioner'),
(17, 'rumah roler'),
(18, 'kaliper'),
(19, 'baut biasa'),
(20, 'baut titan'),
(21, 'shokbeker'),
(22, 'spakbor'),
(23, 'Ecu'),
(24, 'Klahar'),
(25, 'Bearing'),
(123, '');

-- --------------------------------------------------------

--
-- Table structure for table `laporan`
--

CREATE TABLE `laporan` (
  `id_laporan` int(11) NOT NULL,
  `judul_laporan` varchar(150) NOT NULL,
  `jenis` enum('barang_masuk','barang_keluar','stok','semua') NOT NULL,
  `id_barang_keluar` int(11) NOT NULL,
  `id_barang_masuk` int(11) NOT NULL,
  `periode_dari` date DEFAULT NULL,
  `periode_sampai` date DEFAULT NULL,
  `dibuat_oleh` int(11) DEFAULT NULL,
  `tanggal_dibuat` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `laporan`
--

INSERT INTO `laporan` (`id_laporan`, `judul_laporan`, `jenis`, `id_barang_keluar`, `id_barang_masuk`, `periode_dari`, `periode_sampai`, `dibuat_oleh`, `tanggal_dibuat`) VALUES
(101, 'LAPORAN BULAN DESEMBER', 'barang_masuk', 101, 125, '2025-12-01', '2025-12-31', 201, '2025-12-12 11:40:26'),
(102, 'LAPORAN BULAN JANUARI', 'barang_keluar', 102, 124, '2025-01-01', '2025-02-28', 205, '2025-12-13 20:50:14'),
(103, 'LAPORAN BULAN JANUARI', 'barang_masuk', 103, 123, '2025-01-01', '2025-02-01', 201, '2025-12-13 20:51:17'),
(104, 'LAPORAN BULAN FEBRUARI', 'barang_masuk', 104, 122, '2025-02-01', '2025-02-28', 202, '2025-12-13 21:24:06'),
(105, 'LAPORAN BULAN FEBRUARI', 'barang_keluar', 105, 121, '2025-02-01', '2025-02-28', 205, '2025-12-13 21:24:06'),
(106, 'LAPORAN BULAN FEBRUARI', 'barang_keluar', 106, 120, '2025-02-01', '2025-02-28', 221, '2025-12-13 21:24:06'),
(107, 'LAPORAN BULAN MARET', 'barang_masuk', 119, 119, '2025-03-01', '2025-03-31', 211, '2025-12-13 21:24:06'),
(108, 'LAPORAN BULAN MARET', 'barang_keluar', 108, 118, '2025-03-01', '2025-03-31', 214, '2025-12-13 21:24:06'),
(109, 'LAPORAN BULAN APRIL', 'barang_masuk', 109, 117, '2025-04-01', '2025-04-30', 203, '2025-12-13 21:24:06'),
(110, 'LAPORAN BULAN APRIL', 'barang_keluar', 110, 116, '2025-04-01', '2025-04-30', 218, '2025-12-13 21:24:06'),
(111, 'LAPORAN BULAN MEI', 'stok', 111, 115, '2025-05-01', '2025-05-31', 208, '2025-12-13 21:24:06'),
(112, 'LAPORAN BULAN MEI', 'semua', 112, 114, '2025-05-01', '2025-05-31', 216, '2025-12-13 21:24:06'),
(113, 'LAPORAN BULAN MEI', 'barang_keluar', 113, 113, '2025-05-01', '2025-05-31', 206, '2025-12-13 21:24:06'),
(114, 'LAPORAN BULAN JUNI', 'barang_masuk', 114, 112, '2025-06-01', '2025-06-30', 213, '2025-12-13 21:24:06'),
(115, 'LAPORAN BULAN JULI', 'barang_keluar', 115, 111, '2025-07-01', '2025-07-31', 215, '2025-12-13 21:24:06'),
(116, 'LAPORAN BULAN JUNI', 'barang_keluar', 116, 110, '2025-06-01', '2025-06-30', 201, '2025-12-13 21:24:06'),
(117, 'LAPORAN BULAN JULI', 'barang_masuk', 117, 109, '2025-07-01', '2025-07-31', 203, '2025-12-13 21:24:06'),
(118, 'LAPORAN BULAN AGUSTUS', 'barang_masuk', 116, 108, '2025-08-01', '2025-08-31', 206, '2025-12-13 21:24:06'),
(119, 'LAPORAN BULAN SEPTEMBER', 'barang_masuk', 115, 107, '2025-09-01', '2025-09-30', 212, '2025-12-13 21:24:06'),
(120, 'LAPORAN BULAN AGUSTUS', 'barang_keluar', 114, 106, '2025-08-01', '2025-08-31', 210, '2025-12-13 21:24:06'),
(121, 'LAPORAN BULAN OKTOBER', 'barang_keluar', 113, 105, '2025-10-01', '2025-10-31', 202, '2025-12-13 21:24:06'),
(122, 'LAPORAN BULAN NOVEMBER', 'barang_masuk', 112, 104, '2025-11-01', '2025-11-30', 203, '2025-12-13 21:24:06'),
(123, 'LAPORAN BULAN OKTOBER', 'barang_masuk', 111, 103, '2025-10-01', '2025-10-31', 222, '2025-12-13 21:24:06');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(25) NOT NULL,
  `stok` int(11) NOT NULL,
  `nama_supplier` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `stok`, `nama_supplier`) VALUES
(200, 'OLI SHELLL', 20, 'PT.ASTRA'),
(201, 'HANDGRIP DOMINO', 15, 'PT.AHM'),
(203, 'MASTER REM RCB', 27, 'PT.HAAS'),
(204, 'LAMPU SEN ORI YAMAHA', 32, 'PT.ASTRA'),
(205, 'LAMPU BELAKANG', 38, 'PT.AHM'),
(206, 'REFLEKTOR LAMPU WIN', 40, 'PT.HAAS'),
(207, 'LAMPU DEPAN BILED', 37, 'PT.ASTRA'),
(208, 'KAMPAS REM HONDA', 42, 'PT.AHM'),
(209, 'TENSONER YAMAHA', 54, 'PT.HAAS'),
(210, 'ROLER KAWAHARA', 47, 'PT.ASTRA'),
(211, 'OLI MPX', 72, 'PT.AHM'),
(212, 'PULY HONDA', 62, 'PT.ASTRA'),
(213, 'KNALPOT ORI YAMAHA', 80, 'PT.ASTRA'),
(214, 'SPION  HONDA PCX', 90, 'PT.AHM'),
(215, 'KNALPOT ARM', 54, 'PT.ASTRA'),
(216, 'OLI ENDURO MATIC', 62, 'PT.HAAS'),
(217, 'LAMPU AES TURBO', 20, 'PT.AHM'),
(218, 'SPION PCX', 32, 'PT.AHM'),
(311, 'OLI YAMALUBE', 54, 'PT AHASS'),
(411, 'BAN MAXXIS', 42, 'PT.ASTRA'),
(511, 'OLI MPX', 100, 'PT.AHM'),
(611, 'OLI ENDURO RACING', 62, 'PT KURNIA MOTOR'),
(711, 'OLI CASTROL', 20, 'PT.ASTRA'),
(811, 'SHOKBEKER', 40, 'PT.ASTRA'),
(911, 'TENSONER YAMAHA', 20, 'PT YAMAHA'),
(1011, 'ROLER KAWAHARA', 40, 'PT KURNIA MOTOR');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id_supplier` int(11) NOT NULL,
  `nama supplier` varchar(25) NOT NULL,
  `asal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id_supplier`, `nama supplier`, `asal`) VALUES
(1, 'PT.ASTRA', 'CIREBON'),
(2, 'PT.AHM', 'DEPOK'),
(3, 'PT.HAAS', 'JAKARTA'),
(4, 'PT.ASTRA', 'LAMPUNG'),
(5, 'PT.AHM', 'LAMPUNG'),
(6, 'PT.ASTRA', 'JAMBI'),
(7, 'PT.HAAS', 'BANDUNG'),
(8, 'PT.ASTRA', 'PALEMBANG'),
(9, 'PT.ASTRA', 'SEMARANG'),
(10, 'PT.AHM', 'ACEH'),
(11, 'PT.HAAS', 'RIAU'),
(12, 'PT.ASTRA', 'SURABAYA'),
(13, 'PT.AHM', 'INDRAMAYU'),
(14, 'PT.ASTRA', 'GARUT'),
(15, 'PT.HAAS', 'LAMPUNG'),
(16, 'PT.AHM', 'SUMATRA'),
(17, 'PT.ASTRA', 'KENDAL'),
(18, 'PT.AHM', 'CIKARANG'),
(19, 'PT.HAAS', 'PALEMBANG'),
(20, 'PT.ASTRA', 'LAMPUNG'),
(21, 'PT.AHASS', 'CIREBON'),
(22, 'PT.ASTRA', 'ACEH'),
(23, 'PT.YSS', 'DEPOK'),
(24, 'PT.AHASS', 'BOGOR'),
(25, 'PT.ASTRA', 'RIAU');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('pembeli','staff') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `password`, `role`) VALUES
(201, 'Dhesta', 'dsta@gmail.com', 'ayam123', 'pembeli'),
(202, 'irham', 'irham@gmail.com', 'kucing123', 'staff'),
(203, 'prasetya', 'praserya@gmail.com', 'ayam123', 'pembeli'),
(204, 'ham', 'prasetya@gmail.com', 'apake123', 'staff'),
(205, 'abdul', 'dul@gmail.com', 'depok123', 'pembeli'),
(206, 'hafiz', 'fiz@gmail.com', 'fizr123', 'pembeli'),
(207, 'adit', 'dit@gmail.com', 'dit123', 'staff'),
(208, 'adut', 'dut@gmail.com', 'dudut123', 'staff'),
(209, 'di inggris', 'gris@gmail.com', 'ing123', 'staff'),
(210, 'di paris', 'ris@gmail.com', 'riis123', 'pembeli'),
(211, 'dieifel', 'fel@gmail.com', 'menaraeifel123', 'staff'),
(212, 'wongg gede', 'gede@gmail.com', 'sapa123', 'staff'),
(213, 'torr', 'moni@gmail.com', 'tor123', 'pembeli'),
(214, 'ketua', 'tua@gmail.com', 'yua123', 'pembeli'),
(215, 'keplek', 'plek@gmail.com', 'plek123', 'staff'),
(216, 'gun', 'gun@gmail.com', 'gun123', 'pembeli'),
(217, 'awan', 'awan@gmail.com', 'wan123', 'staff'),
(218, 'jerman', 'man@gmail.com', 'man123', 'staff'),
(219, 'dicerbon', 'bon@gmail.com', 'bon123', 'pembeli'),
(220, 'guna darma', 'gunawan@gmail.com', 'gun123', 'staff'),
(221, 'haidir', 'idir@gmail.com', 'dir123', 'staff'),
(222, 'din', 'din@gmail.com', 'din123', 'pembeli');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD PRIMARY KEY (`id_barang_keluar`),
  ADD KEY `id_produk` (`id_produk`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD PRIMARY KEY (`id_barang_masuk`),
  ADD UNIQUE KEY `id_kategori` (`id_kategori`),
  ADD KEY `id_produk` (`id_produk`),
  ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`id_laporan`),
  ADD KEY `dibuat_oleh` (`dibuat_oleh`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  MODIFY `id_barang_keluar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  MODIFY `id_barang_masuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `laporan`
--
ALTER TABLE `laporan`
  MODIFY `id_laporan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1012;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD CONSTRAINT `barang_masuk_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
