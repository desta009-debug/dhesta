<?php
// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'reborn_final');

// Koneksi ke Database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error . "<br>Database: " . DB_NAME . "<br>Host: " . DB_HOST);
}

// Set charset
$conn->set_charset("utf8");

// Session - Cek apakah session sudah aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fungsi untuk membersihkan input
function clean_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = $conn->real_escape_string($data);
    return $data;
}

// Fungsi untuk redirect
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// Fungsi untuk cek login
function check_login() {
    if (!isset($_SESSION['user_id'])) {
        redirect('login.php');
    }
}

// Fungsi untuk cek role
function check_role($role) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] != $role) {
        redirect('login.php');
    }
}

// Fungsi untuk alert dan redirect
function alert_redirect($message, $url) {
    echo "<script>
        alert('$message');
        window.location.href = '$url';
    </script>";
    exit();
}

// Fungsi untuk alert
function alert($message) {
    echo "<script>alert('$message');</script>";
}
date_default_timezone_set('Asia/Jakarta');

?>
