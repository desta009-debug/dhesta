<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'staff') {
        redirect('dashboard_staff.php');
    } else {
        redirect('dashboard_pembeli.php');
    }
}

$error = '';

// Proses login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = clean_input($_POST['email']);
    $password = clean_input($_POST['password']);
    
    if (empty($email) || empty($password)) {
        $error = "Email dan password harus diisi!";
    } else {
        // Query untuk mencari user berdasarkan email
        $query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
        $result = mysqli_query($conn, $query);
        
        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            
            // Cek password (plain text comparison)
            if ($password === $user['password']) {
                // Set session
                $_SESSION['user_id'] = $user['id_user'];
                $_SESSION['nama'] = $user['nama'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                
                // Redirect berdasarkan role
                if ($user['role'] == 'staff') {
                    redirect('dashboard_staff.php');
                } else {
                    redirect('dashboard_pembeli.php');
                }
            } else {
                $error = "Password salah!";
            }
        } else {
            $error = "Email tidak terdaftar!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    margin: 0;
    min-height: 100vh;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    padding: 40px 20px;
    position: relative;
    overflow-y: auto;
    overflow-x: hidden;
}

/* ========== PAGE WRAPPER ========== */
.page-wrapper {
    min-height: calc(100vh - 80px);
    display: flex;
    justify-content: center;
    align-items: center;
}

/* ========== LOGIN CONTAINER ========== */
.login-container {
    background: white;
    padding: 50px 45px;
    width: 100%;
    max-width: 450px;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    position: relative;
    z-index: 10;
    animation: slideUp 0.5s ease-out;
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ========== LOGO & HEADER ========== */
.logo-section {
    text-align: center;
    margin-bottom: 35px;
}

.logo-image {
    width: 140px;
    height: 140px;
    object-fit: cover;
    border-radius: 50%;
    margin-bottom: 25px;
    box-shadow: 
        0 10px 30px rgba(0, 0, 0, 0.15),
        0 0 40px rgba(67, 160, 71, 0.3);
    border: 4px solid white;
    transition: transform 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-section h1 {
    font-size: 32px;
    color: var(--primary);
    margin-bottom: 8px;
    font-weight: 700;
}

.logo-section p {
    color: #666;
    font-size: 15px;
    font-weight: 500;
}

/* ========== ERROR MESSAGE ========== */
.error-message {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
    padding: 15px 20px;
    margin-bottom: 25px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(244, 67, 54, 0.3);
    animation: shake 0.5s ease-in-out;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-10px); }
    75% { transform: translateX(10px); }
}

.error-icon {
    font-size: 22px;
}

/* ========== FORM ========== */
.login-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.form-group {
    position: relative;
}

.form-group label {
    display: block;
    color: var(--primary);
    font-weight: 600;
    margin-bottom: 8px;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
}

.input-icon {
    position: absolute;
    left: 18px;
    font-size: 20px;
    color: #999;
    transition: color 0.3s;
}

.form-group input {
    width: 100%;
    padding: 16px 20px 16px 55px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    font-size: 16px;
    transition: all 0.3s;
    background: #fafafa;
}

.form-group input:focus {
    outline: none;
    border-color: var(--accent);
    background: white;
    box-shadow: 0 0 0 4px rgba(67, 160, 71, 0.1);
}

.form-group input:focus + .input-icon {
    color: var(--accent);
}

/* ========== BUTTON ========== */
.btn-login {
    width: 100%;
    padding: 16px;
    border: none;
    border-radius: 12px;
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 10px;
    box-shadow: 0 6px 20px rgba(67, 160, 71, 0.3);
}

.btn-login:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(67, 160, 71, 0.4);
}

.btn-login:active {
    transform: translateY(-1px);
}

/* ========== FORGOT PASSWORD ========== */
.forgot-password-section {
    text-align: center;
    margin-top: 20px;
}

.forgot-password {
    font-size: 13px;
    font-weight: 600;
    color: var(--info);
    text-decoration: none;
    transition: all 0.3s;
    position: relative;
    display: inline-block;
}

.forgot-password::after {
    content: '';
    position: absolute;
    bottom: -3px;
    left: 0;
    width: 0;
    height: 2px;
    background: linear-gradient(135deg, var(--info), #42a5f5);
    transition: width 0.3s;
}

.forgot-password:hover::after {
    width: 100%;
}

/* ========== REGISTER SECTION (DITAMBAHKAN) ========== */
.register-section {
    margin-top: 25px;
    padding-top: 25px;
    border-top: 2px solid #e0e0e0;
    text-align: center;
}

.register-section p {
    color: #666;
    font-size: 14px;
    margin-bottom: 15px;
    font-weight: 500;
}

.btn-register {
    display: inline-block;
    padding: 12px 30px;
    background: linear-gradient(135deg, var(--info) 0%, #42a5f5 100%);
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 700;
    transition: all 0.3s;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 4px 15px rgba(30, 136, 229, 0.3);
}

.btn-register:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(30, 136, 229, 0.4);
}

/* ========== FOOTER ========== */
.login-footer {
    margin-top: 30px;
    text-align: center;
}

.features {
    display: flex;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.feature-item {
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--primary);
    font-size: 13px;
    font-weight: 600;
}

.feature-icon {
    font-size: 16px;
    color: var(--accent);
}

/* ========== COPYRIGHT ========== */
.copyright {
    text-align: center;
    padding: 20px 0 10px;
    color: #999;
    font-size: 12px;
}

.copyright p {
    margin-bottom: 5px;
}

.copyright .version {
    opacity: 0.7;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 480px) {
    body {
        padding: 20px 15px;
    }
    
    .login-container {
        padding: 35px 30px;
    }
    
    .logo-section h1 {
        font-size: 26px;
    }
    
    .logo-image {
        width: 120px;
        height: 120px;
    }
    
    .features {
        flex-direction: column;
        gap: 10px;
    }
}

/* ========== LOADING STATE ========== */
.btn-login.loading {
    position: relative;
    color: transparent;
    pointer-events: none;
}

.btn-login.loading::after {
    content: '';
    position: absolute;
    width: 20px;
    height: 20px;
    top: 50%;
    left: 50%;
    margin-left: -10px;
    margin-top: -10px;
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}
</style>
</head>

<body>

<div class="page-wrapper">
    <div class="login-container">
        <!-- Logo Section -->
        <div class="logo-section">
            <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
            <h1>Reborn Garage</h1>
            <p>Sistem Manajemen Inventory</p>
        </div>

        <!-- Error Message -->
        <?php if ($error): ?>
            <div class="error-message">
                <span class="error-icon">⚠️</span>
                <span><?= htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>

        <!-- Login Form -->
        <form method="POST" class="login-form" id="loginForm">
            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-wrapper">
                    <input type="email" 
                           id="email" 
                           name="email" 
                           placeholder="Masukkan email Anda" 
                           required
                           autocomplete="email">
                    <span class="input-icon">📧</span>
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrapper">
                    <input type="password" 
                           id="password" 
                           name="password" 
                           placeholder="Masukkan password" 
                           required
                           autocomplete="current-password">
                    <span class="input-icon">🔒</span>
                </div>
            </div>

            <button type="submit" class="btn-login" id="btnLogin">
                LOGIN✓ 
            </button>
        </form>

        <!-- Forgot Password -->
        <div class="forgot-password-section">
            <a href="#" class="forgot-password">Lupa Password?</a>
        </div>

        <!-- Register Section (DITAMBAHKAN DARI FILE LAMA) -->
        <div class="register-section">
            <p>Belum punya akun?</p>
            <a href="register.php" class="btn-register">
                📝 Daftar Sebagai Pembeli
            </a>
        </div>

        <!-- Footer -->
        <div class="login-footer">
            <div class="features">
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Aman</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Cepat</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Terpercaya</span>
                </div>
            </div>
            
            <!-- Copyright -->
            <div class="copyright">
                <p>© 2026 Reborn Garage. All rights reserved.</p>
                <p class="version">Version 1.0</p>
            </div>
        </div>
    </div>
</div>

<script>
// Smooth page load animation
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s';
        document.body.style.opacity = '1';
    }, 100);
});

// Form submission with loading state
document.getElementById('loginForm').addEventListener('submit', function() {
    const btn = document.getElementById('btnLogin');
    btn.classList.add('loading');
});

// Input focus effects
const inputs = document.querySelectorAll('.form-group input');
inputs.forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.style.transform = 'scale(1.02)';
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.style.transform = 'scale(1)';
    });
});
</script>

</body>
</html>