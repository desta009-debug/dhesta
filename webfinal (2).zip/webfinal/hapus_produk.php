<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: data_produk.php");
    exit;
}

$id_produk = (int)$_GET['id'];

$produk_query = mysqli_query($conn, "SELECT gambar FROM produk WHERE id_produk = $id_produk");

if (mysqli_num_rows($produk_query) > 0) {
    $produk = mysqli_fetch_assoc($produk_query);
    
    if ($produk['gambar'] && file_exists('uploads/' . $produk['gambar'])) {
        unlink('uploads/' . $produk['gambar']);
    }
    
    $delete_query = "DELETE FROM produk WHERE id_produk = $id_produk";
    
    if (mysqli_query($conn, $delete_query)) {
        $_SESSION['delete_success'] = "Produk berhasil dihapus!";
    } else {
        $_SESSION['delete_error'] = "Gagal menghapus produk: " . mysqli_error($conn);
    }
} else {
    $_SESSION['delete_error'] = "Produk tidak ditemukan!";
}

header("Location: data_produk.php");
exit;
?>