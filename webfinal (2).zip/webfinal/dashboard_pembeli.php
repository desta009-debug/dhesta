<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pembeli') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Pembeli';

// Get stats for dashboard
$total_produk = mysqli_num_rows(mysqli_query($conn, "SELECT id_produk FROM produk"));
$total_orders = mysqli_num_rows(mysqli_query($conn, "SELECT id_order FROM orders WHERE id_user = $id_user"));
$pending_orders = mysqli_num_rows(mysqli_query($conn, "SELECT id_order FROM orders WHERE id_user = $id_user AND status = 'pending'"));
$completed_orders = mysqli_num_rows(mysqli_query($conn, "SELECT id_order FROM orders WHERE id_user = $id_user AND status = 'completed'"));

// Get total spending
$total_spending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_harga) as total FROM orders WHERE id_user = $id_user"))['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Pembeli - Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

/* ========== LOGO ========== */
.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.sidebar.small .logo-image {
    width: 50px;
    height: 50px;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
    position: relative;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== WELCOME SECTION ========== */
.welcome-section {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 60px 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.welcome-section h1 {
    font-size: 42px;
    margin-bottom: 10px;
    font-weight: 700;
}

.welcome-section p {
    font-size: 18px;
    opacity: 0.9;
}

/* ========== STATS CARDS ========== */
.stats-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
}

.stat-card {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    transition: all 0.3s;
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, var(--accent), var(--success));
}

.stat-card:nth-child(2)::before {
    background: linear-gradient(90deg, var(--info), #42a5f5);
}

.stat-card:nth-child(3)::before {
    background: linear-gradient(90deg, var(--warning), #ffb74d);
}

.stat-card:nth-child(4)::before {
    background: linear-gradient(90deg, var(--danger), #ef5350);
}

.stat-card:nth-child(5)::before {
    background: linear-gradient(90deg, #9c27b0, #ba68c8);
}

.stat-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.15);
}

.stat-icon {
    font-size: 48px;
    margin-bottom: 15px;
    display: block;
}

.stat-value {
    font-size: 42px;
    font-weight: 700;
    color: var(--primary);
    line-height: 1;
    margin-bottom: 8px;
}

.stat-label {
    font-size: 14px;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 600;
}

.stat-value.currency {
    font-size: 28px;
}

/* ========== QUICK ACTIONS ========== */
.quick-actions {
    background: white;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.quick-actions h2 {
    font-size: 24px;
    color: var(--primary);
    margin-bottom: 25px;
    font-weight: 700;
}

.action-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}

.action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 30px 20px;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    text-decoration: none;
    border-radius: 12px;
    transition: all 0.3s;
    text-align: center;
}

.action-btn:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.action-btn .icon {
    font-size: 48px;
    margin-bottom: 12px;
}

.action-btn .label {
    font-size: 16px;
    font-weight: 600;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .sidebar .badge-content {
        justify-content: center;
        border-left: none;
        background: transparent;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .welcome-section h1 {
        font-size: 28px;
    }
    
    .welcome-section p {
        font-size: 16px;
    }
    
    .stats-container {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    }
    
    .stat-value {
        font-size: 32px;
    }
    
    .stat-value.currency {
        font-size: 24px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <!-- USER INFO -->
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👋</span>
            <span class="badge-text">Halo, <?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_pembeli.php" class="active">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="produk.php">
            <span class="icon">🛍️</span>
            <span>Belanja Produk</span>
        </a>
        <a href="keranjang.php">
            <span class="icon">🛒</span>
            <span>Keranjang</span>
        </a>
        <a href="riwayat_pesanan.php">
            <span class="icon">📋</span>
            <span>Riwayat Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- WELCOME SECTION -->
    <div class="welcome-section">
        <h1>Selamat Datang, <?= htmlspecialchars($nama_user); ?>!</h1>
        <p>Temukan produk berkualitas dan kelola pesanan Anda dengan mudah</p>
    </div>

    <!-- STATS -->
    <div class="stats-container">
        <div class="stat-card">
            <span class="stat-icon">🛍️</span>
            <div class="stat-value"><?= $total_produk ?></div>
            <div class="stat-label">Produk Tersedia</div>
        </div>
        <div class="stat-card">
            <span class="stat-icon">📊</span>
            <div class="stat-value"><?= $total_orders ?></div>
            <div class="stat-label">Total Pesanan</div>
        </div>
        <div class="stat-card">
            <span class="stat-icon">⏳</span>
            <div class="stat-value"><?= $pending_orders ?></div>
            <div class="stat-label">Pesanan Menunggu</div>
        </div>
        <div class="stat-card">
            <span class="stat-icon">✓</span>
            <div class="stat-value"><?= $completed_orders ?></div>
            <div class="stat-label">Pesanan Selesai</div>
        </div>
        <div class="stat-card">
            <span class="stat-icon">💰</span>
            <div class="stat-value currency">Rp <?= number_format($total_spending, 0, ',', '.') ?></div>
            <div class="stat-label">Total Pengeluaran</div>
        </div>
    </div>

    <!-- QUICK ACTIONS -->
    <div class="quick-actions">
        <h2>🚀 Quick Actions</h2>
        <div class="action-grid">
            <a href="produk.php" class="action-btn">
                <span class="icon">🛍️</span>
                <span class="label">Jelajahi Produk</span>
            </a>
            <a href="keranjang.php" class="action-btn">
                <span class="icon">🛒</span>
                <span class="label">Lihat Keranjang</span>
            </a>
            <a href="riwayat_pesanan.php" class="action-btn">
                <span class="icon">📋</span>
                <span class="label">Riwayat Pesanan</span>
            </a>
        </div>
    </div>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.3s';
        document.body.style.opacity = '1';
    }, 100);
});
</script>

</body>
</html>
