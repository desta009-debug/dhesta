<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pembeli') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Pembeli';

$success_msg = $_SESSION['checkout_success'] ?? '';
unset($_SESSION['checkout_success']);
$error_msg = $_SESSION['checkout_error'] ?? '';
unset($_SESSION['checkout_error']);

$orders_query = "SELECT o.id_order, o.id_user, o.total_harga, o.metode_pembayaran, o.status, o.tanggal_order FROM orders o WHERE o.id_user = $id_user ORDER BY o.id_order DESC";
$orders = mysqli_query($conn, $orders_query);

if (!$orders) {
    die("<h1>Database Error: " . mysqli_error($conn) . "</h1>");
}

$total_orders = mysqli_num_rows($orders);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Riwayat Pesanan - Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== PAGE HEADER ========== */
.page-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.page-header h1 {
    font-size: 36px;
    margin-bottom: 8px;
    font-weight: 700;
}

.page-header p {
    font-size: 16px;
    opacity: 0.9;
}

/* ========== NOTIFICATIONS ========== */
.notification {
    padding: 15px 20px;
    margin-bottom: 25px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideIn 0.5s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.notification.success {
    background: linear-gradient(135deg, var(--success), #66bb6a);
    color: white;
    box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
}

.notification.error {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
    box-shadow: 0 4px 15px rgba(244, 67, 54, 0.3);
}

/* ========== STATS BAR ========== */
.stats-bar {
    background: white;
    padding: 20px 30px;
    border-radius: 12px;
    margin-bottom: 30px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    display: flex;
    align-items: center;
    gap: 15px;
}

.stats-bar .icon {
    font-size: 32px;
}

.stats-bar .text {
    flex: 1;
}

.stats-bar .label {
    font-size: 14px;
    color: #666;
    margin-bottom: 4px;
}

.stats-bar .value {
    font-size: 24px;
    font-weight: 700;
    color: var(--primary);
}

/* ========== ORDER CARD ========== */
.order-card {
    background: white;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    padding: 30px;
    margin-bottom: 25px;
    transition: all 0.3s;
}

.order-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.12);
}

.order-header {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
    padding-bottom: 20px;
    border-bottom: 2px solid #f0f0f0;
}

.order-info {
    display: flex;
    flex-direction: column;
}

.order-label {
    font-size: 12px;
    color: #666;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
}

.order-value {
    font-size: 20px;
    font-weight: 700;
    color: var(--primary);
}

.status-badge {
    display: inline-block;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 700;
    width: fit-content;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.status-pending {
    background: linear-gradient(135deg, var(--warning), #ffb74d);
    color: white;
}

.status-completed {
    background: linear-gradient(135deg, var(--success), #66bb6a);
    color: white;
}

.status-cancelled {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
}

.payment-method {
    padding: 15px 20px;
    background: #f9f9f9;
    border-radius: 12px;
    margin-bottom: 20px;
}

.payment-method strong {
    display: block;
    margin-bottom: 8px;
    color: var(--primary);
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.payment-method span {
    color: #666;
    font-size: 16px;
    font-weight: 500;
}

.order-items {
    margin-top: 20px;
}

.order-items-title {
    font-size: 16px;
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.order-item {
    display: grid;
    grid-template-columns: 1fr 100px 150px;
    gap: 20px;
    padding: 15px;
    border-bottom: 1px solid #f0f0f0;
    align-items: center;
}

.order-item:last-child {
    border-bottom: none;
}

.item-name {
    font-weight: 600;
    color: var(--primary);
    font-size: 15px;
}

.item-qty {
    text-align: center;
    color: #666;
    font-size: 14px;
    font-weight: 500;
}

.item-price {
    text-align: right;
    color: var(--accent);
    font-weight: 700;
    font-size: 16px;
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 80px 20px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.empty-state-icon {
    font-size: 100px;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-state h2 {
    font-size: 28px;
    color: var(--primary);
    margin-bottom: 10px;
}

.empty-state p {
    color: #666;
    font-size: 16px;
    margin-bottom: 30px;
}

.empty-state a {
    display: inline-block;
    padding: 15px 40px;
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    text-decoration: none;
    border-radius: 12px;
    font-weight: 700;
    transition: all 0.3s;
    box-shadow: 0 6px 20px rgba(67, 160, 71, 0.3);
}

.empty-state a:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(67, 160, 71, 0.4);
}

/* ========== RESPONSIVE ========== */
@media (max-width: 968px) {
    .order-header {
        grid-template-columns: 1fr 1fr;
    }
    
    .order-item {
        grid-template-columns: 1fr;
        gap: 10px;
    }
    
    .item-qty, .item-price {
        text-align: left;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header h1 {
        font-size: 28px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👋</span>
            <span class="badge-text">Halo, <?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_pembeli.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="produk.php">
            <span class="icon">🛍️</span>
            <span>Belanja Produk</span>
        </a>
        <a href="keranjang.php">
            <span class="icon">🛒</span>
            <span>Keranjang</span>
        </a>
        <a href="riwayat_pesanan.php" class="active">
            <span class="icon">📋</span>
            <span>Riwayat Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h1>📋 Riwayat Pesanan</h1>
        <p>Lihat dan kelola semua pesanan Anda</p>
    </div>

    <!-- NOTIFICATIONS -->
    <?php if (!empty($success_msg)): ?>
        <div class="notification success">
            <span>✅</span>
            <span><?= htmlspecialchars($success_msg); ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div class="notification error">
            <span>⚠️</span>
            <span><?= htmlspecialchars($error_msg); ?></span>
        </div>
    <?php endif; ?>

    <?php if ($total_orders > 0): ?>
        <!-- STATS BAR -->
        <div class="stats-bar">
            <span class="icon">📊</span>
            <div class="text">
                <div class="label">Total Pesanan</div>
                <div class="value"><?= $total_orders; ?> Pesanan</div>
            </div>
        </div>

        <!-- ORDER CARDS -->
        <?php while ($order = mysqli_fetch_assoc($orders)): 
            $order_id = $order['id_order'];
        ?>
            <div class="order-card">
                <div class="order-header">
                    <div class="order-info">
                        <span class="order-label">No. Pesanan</span>
                        <span class="order-value">#<?= $order_id; ?></span>
                    </div>
                    <div class="order-info">
                        <span class="order-label">Tanggal Order</span>
                        <span class="order-value"><?= date('d M Y', strtotime($order['tanggal_order'])); ?></span>
                    </div>
                    <div class="order-info">
                        <span class="order-label">Total Pembayaran</span>
                        <span class="order-value">Rp <?= number_format($order['total_harga'], 0, ',', '.'); ?></span>
                    </div>
                    <div class="order-info">
                        <span class="order-label">Status</span>
                        <span class="status-badge status-<?= $order['status']; ?>">
                            <?php 
                                $status = [
                                    'pending' => '⏳ Menunggu', 
                                    'completed' => '✅ Selesai', 
                                    'cancelled' => '❌ Dibatalkan'
                                ];
                                echo $status[$order['status']] ?? $order['status'];
                            ?>
                        </span>
                    </div>
                </div>

                <div class="payment-method">
                    <strong>💳 Metode Pembayaran:</strong>
                    <span>
                        <?php
                            $methods = [
                                'transfer_bank' => '🏦 Transfer Bank', 
                                'e_wallet' => '📱 E-Wallet', 
                                'cicilan' => '💳 Cicilan', 
                                'cash' => '💰 Bayar di Tempat'
                            ];
                            echo $methods[$order['metode_pembayaran']] ?? $order['metode_pembayaran'];
                        ?>
                    </span>
                </div>

                <div class="order-items">
                    <div class="order-items-title">
                        <span>📦</span>
                        <span>Detail Item Pesanan</span>
                    </div>
                    <?php
                        $items = mysqli_query($conn, "
                            SELECT oi.jumlah, oi.subtotal, p.nama_produk 
                            FROM order_items oi 
                            JOIN produk p ON oi.id_produk = p.id_produk 
                            WHERE oi.id_order = $order_id
                        ");

                        if ($items && mysqli_num_rows($items) > 0) {
                            while ($item = mysqli_fetch_assoc($items)) {
                                echo '<div class="order-item">';
                                echo '<div class="item-name">' . htmlspecialchars($item['nama_produk']) . '</div>';
                                echo '<div class="item-qty">' . $item['jumlah'] . ' unit</div>';
                                echo '<div class="item-price">Rp ' . number_format($item['subtotal'], 0, ',', '.') . '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo '<p style="color: var(--warning); padding: 15px; text-align: center;">⚠️ Tidak ada item dalam pesanan ini</p>';
                        }
                    ?>
                </div>
            </div>
        <?php endwhile; ?>

    <?php else: ?>
        <!-- EMPTY STATE -->
        <div class="empty-state">
            <div class="empty-state-icon">📭</div>
            <h2>Belum Ada Pesanan</h2>
            <p>Yuk mulai belanja dan buat pesanan pertama Anda!</p>
            <a href="produk.php">🛍️ Mulai Belanja Sekarang</a>
        </div>
    <?php endif; ?>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.3s';
        document.body.style.opacity = '1';
    }, 100);
});

// Auto-hide notifications
const notifications = document.querySelectorAll('.notification');
notifications.forEach(notif => {
    setTimeout(() => {
        notif.style.transition = 'all 0.5s';
        notif.style.opacity = '0';
        notif.style.transform = 'translateY(-20px)';
        setTimeout(() => notif.remove(), 500);
    }, 5000);
});
</script>

</body>
</html>