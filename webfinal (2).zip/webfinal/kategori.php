<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Admin Staff';

$success = "";
$error = "";

// Handle Tambah Kategori
if (isset($_POST['tambah_kategori'])) {
    $nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']);
    
    // Check if kategori already exists
    $check_query = mysqli_query($conn, "SELECT * FROM kategori WHERE nama_kategori = '$nama_kategori'");
    if (mysqli_num_rows($check_query) > 0) {
        $error = "Kategori dengan nama '$nama_kategori' sudah ada!";
    } else {
        $query = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
        if (mysqli_query($conn, $query)) {
            $success = "Kategori berhasil ditambahkan!";
        } else {
            $error = "Gagal menambahkan kategori: " . mysqli_error($conn);
        }
    }
}

// Handle Edit Kategori
if (isset($_POST['edit_kategori'])) {
    $id_kategori = (int)$_POST['id_kategori'];
    $nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']);
    
    // Check if kategori name already exists (except current)
    $check_query = mysqli_query($conn, "SELECT * FROM kategori WHERE nama_kategori = '$nama_kategori' AND id_kategori != $id_kategori");
    if (mysqli_num_rows($check_query) > 0) {
        $error = "Kategori dengan nama '$nama_kategori' sudah ada!";
    } else {
        $query = "UPDATE kategori SET nama_kategori = '$nama_kategori' WHERE id_kategori = $id_kategori";
        if (mysqli_query($conn, $query)) {
            $success = "Kategori berhasil diperbarui!";
        } else {
            $error = "Gagal memperbarui kategori: " . mysqli_error($conn);
        }
    }
}

// Handle Delete Kategori
if (isset($_POST['delete_kategori'])) {
    $id_kategori = (int)$_POST['id_kategori'];
    
    // Check if kategori is being used by products
    $check_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM produk WHERE id_kategori = $id_kategori");
    $check_result = mysqli_fetch_assoc($check_query);
    
    if ($check_result['count'] > 0) {
        $error = "Tidak dapat menghapus kategori karena masih digunakan oleh " . $check_result['count'] . " produk!";
    } else {
        $query = "DELETE FROM kategori WHERE id_kategori = $id_kategori";
        if (mysqli_query($conn, $query)) {
            $success = "Kategori berhasil dihapus!";
        } else {
            $error = "Gagal menghapus kategori: " . mysqli_error($conn);
        }
    }
}

// Get all categories with product count
$kategori_query = "
    SELECT k.*, 
           COUNT(p.id_produk) as total_produk 
    FROM kategori k 
    LEFT JOIN produk p ON k.id_kategori = p.id_kategori 
    GROUP BY k.id_kategori 
    ORDER BY k.nama_kategori ASC
";
$kategori_result = mysqli_query($conn, $kategori_query);

// Calculate statistics
$total_kategori = mysqli_num_rows($kategori_result);
$active_kategori = mysqli_num_rows(mysqli_query($conn, "
    SELECT DISTINCT k.id_kategori 
    FROM kategori k 
    INNER JOIN produk p ON k.id_kategori = p.id_kategori
"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Kategori - Reborn Garage</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
}

.badge-icon {
    font-size: 18px;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s;
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== PAGE HEADER ========== */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 35px;
    flex-wrap: wrap;
    gap: 20px;
}

.page-header h2 {
    color: var(--primary);
    font-size: 32px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
}

/* ========== ALERT ========== */
.alert {
    padding: 16px 20px;
    border-radius: 12px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideDown 0.3s ease;
}

.alert-success {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
    border-left: 4px solid var(--success);
}

.alert-error {
    background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%);
    color: #b71c1c;
    border-left: 4px solid var(--danger);
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ========== STATS CARDS ========== */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.12);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
}

.stat-icon.info { background: linear-gradient(135deg, #1e88e5, #42a5f5); }
.stat-icon.success { background: linear-gradient(135deg, #4caf50, #66bb6a); }

.stat-details h3 {
    font-size: 14px;
    color: #666;
    margin-bottom: 5px;
    font-weight: 500;
}

.stat-details .stat-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary);
}

/* ========== ACTIONS BAR ========== */
.actions-bar {
    background: white;
    padding: 25px;
    border-radius: 16px;
    margin-bottom: 30px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.btn {
    padding: 12px 24px;
    border-radius: 10px;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    border: none;
}

.btn-primary {
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    box-shadow: 0 4px 15px rgba(67,160,71,0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #2e7d32, #388e3c);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(67,160,71,0.4);
}

.btn-edit {
    background: linear-gradient(135deg, var(--info), #42a5f5);
    color: white;
    padding: 8px 16px;
    font-size: 13px;
}

.btn-edit:hover {
    background: linear-gradient(135deg, #1565c0, #1976d2);
    transform: translateY(-2px);
}

.btn-delete {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
    padding: 8px 16px;
    font-size: 13px;
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c62828, #d32f2f);
    transform: translateY(-2px);
}

/* ========== TABLE ========== */
.table-container {
    background: white;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    overflow: hidden;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background: var(--primary);
    color: white;
}

th {
    padding: 18px 16px;
    text-align: left;
    font-weight: 700;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

td {
    padding: 16px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 14px;
}

tbody tr {
    transition: all 0.2s;
}

tbody tr:hover {
    background: #f8f9fa;
}

/* ========== BADGES ========== */
.badge {
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 700;
    display: inline-block;
}

.badge-info {
    background: linear-gradient(135deg, #e3f2fd, #bbdefb);
    color: #0d47a1;
}

.badge-success {
    background: linear-gradient(135deg, #c8e6c9, #a5d6a7);
    color: #1b5e20;
}

.badge-warning {
    background: linear-gradient(135deg, #fff3e0, #ffe0b2);
    color: #e65100;
}

/* ========== MODAL ========== */
.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.6);
    animation: fadeIn 0.3s;
}

.modal-content {
    background: white;
    margin: 80px auto;
    padding: 40px;
    border-radius: 16px;
    max-width: 600px;
    animation: slideUp 0.3s;
}

@keyframes slideUp {
    from {
        transform: translateY(50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
}

.modal-header h2 {
    color: var(--primary);
    font-size: 24px;
}

.close {
    font-size: 32px;
    font-weight: 700;
    color: #999;
    cursor: pointer;
    transition: all 0.3s;
}

.close:hover {
    color: var(--danger);
    transform: scale(1.2);
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--primary);
}

.form-group input {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 14px;
    transition: all 0.3s;
}

.form-group input:focus {
    outline: none;
    border-color: var(--accent);
    box-shadow: 0 4px 12px rgba(67,160,71,0.1);
}

.modal-actions {
    display: flex;
    gap: 15px;
    margin-top: 25px;
}

.btn-secondary {
    background: #e0e0e0;
    color: #333;
}

.btn-secondary:hover {
    background: #d0d0d0;
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-state .icon {
    font-size: 64px;
    margin-bottom: 20px;
}

.empty-state h3 {
    font-size: 24px;
    margin-bottom: 10px;
    color: #666;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .actions-bar {
        flex-direction: column;
        gap: 15px;
    }
    
    .table-container {
        overflow-x: auto;
    }
    
    table {
        min-width: 600px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👤</span>
            <span class="badge-text"><?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_staff.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="data_produk.php">
            <span class="icon">📦</span>
            <span>Kelola Produk</span>
        </a>
        <a href="kategori.php" class="active">
            <span class="icon">🏷️</span>
            <span>Kategori</span>
        </a>
        <a href="supplier.php">
            <span class="icon">🏭</span>
            <span>Supplier</span>
        </a>
        <a href="barang_masuk.php">
            <span class="icon">📥</span>
            <span>Barang Masuk</span>
        </a>
        <a href="barang_keluar.php">
            <span class="icon">📤</span>
            <span>Barang Keluar</span>
        </a>
        <a href="kelola_pesanan.php">
            <span class="icon">📋</span>
            <span>Kelola Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h2>
            <span>🏷️</span>
            Kelola Kategori Produk
        </h2>
        <button class="btn btn-primary" onclick="openAddModal()">
            <span>➕</span>
            Tambah Kategori
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <span>✅</span>
            <span><?= $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-error">
            <span>❌</span>
            <span><?= $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- STATISTICS CARDS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon info">🏷️</div>
            <div class="stat-details">
                <h3>Total Kategori</h3>
                <div class="stat-value"><?= $total_kategori ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon success">✓</div>
            <div class="stat-details">
                <h3>Kategori Aktif</h3>
                <div class="stat-value"><?= $active_kategori ?></div>
            </div>
        </div>
    </div>

    <!-- TABLE SECTION -->
    <div class="table-container">
        <?php if (mysqli_num_rows($kategori_result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NAMA KATEGORI</th>
                        <th>TOTAL PRODUK</th>
                        <th>STATUS</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    mysqli_data_seek($kategori_result, 0);
                    while ($kategori = mysqli_fetch_assoc($kategori_result)): 
                    ?>
                        <tr>
                            <td><strong><?= $kategori['id_kategori'] ?></strong></td>
                            <td>
                                <strong style="font-size: 15px;">🏷️ <?= htmlspecialchars($kategori['nama_kategori']) ?></strong>
                            </td>
                            <td>
                                <span class="badge <?= $kategori['total_produk'] > 0 ? 'badge-info' : 'badge-warning' ?>">
                                    <?= $kategori['total_produk'] ?> Produk
                                </span>
                            </td>
                            <td>
                                <?php if ($kategori['total_produk'] > 0): ?>
                                    <span class="badge badge-success">✓ Aktif</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">○ Tidak Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-edit" onclick='openEditModal(<?= json_encode($kategori) ?>)'>
                                    🖊️ Edit
                                </button>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus kategori ini?')">
                                    <input type="hidden" name="id_kategori" value="<?= $kategori['id_kategori'] ?>">
                                    <button type="submit" name="delete_kategori" class="btn btn-delete">
                                        🗑️ Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state">
                <div class="icon">🏷️</div>
                <h3>Belum Ada Kategori</h3>
                <p>Klik tombol "Tambah Kategori" untuk menambahkan kategori baru</p>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- MODAL TAMBAH KATEGORI -->
<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>➕ Tambah Kategori Baru</h2>
            <span class="close" onclick="closeAddModal()">&times;</span>
        </div>
        <form method="POST">
            <div class="form-group">
                <label>🏷️ Nama Kategori <span style="color: red;">*</span></label>
                <input type="text" name="nama_kategori" placeholder="Contoh: Oli, Ban, Lampu" required>
            </div>
            <div class="modal-actions">
                <button type="submit" name="tambah_kategori" class="btn btn-primary">
                    💾 Simpan
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeAddModal()">
                    ❌ Batal
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL EDIT KATEGORI -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>✏️ Edit Kategori</h2>
            <span class="close" onclick="closeEditModal()">&times;</span>
        </div>
        <form method="POST">
            <input type="hidden" name="id_kategori" id="edit_id_kategori">
            <div class="form-group">
                <label>🏷️ Nama Kategori <span style="color: red;">*</span></label>
                <input type="text" name="nama_kategori" id="edit_nama_kategori" required>
            </div>
            <div class="modal-actions">
                <button type="submit" name="edit_kategori" class="btn btn-primary">
                    💾 Simpan Perubahan
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">
                    ❌ Batal
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

function openAddModal() {
    document.getElementById('addModal').style.display = 'block';
}

function closeAddModal() {
    document.getElementById('addModal').style.display = 'none';
}

function openEditModal(kategori) {
    document.getElementById('edit_id_kategori').value = kategori.id_kategori;
    document.getElementById('edit_nama_kategori').value = kategori.nama_kategori;
    document.getElementById('editModal').style.display = 'block';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const addModal = document.getElementById('addModal');
    const editModal = document.getElementById('editModal');
    if (event.target == addModal) {
        closeAddModal();
    }
    if (event.target == editModal) {
        closeEditModal();
    }
}

// Auto-hide success/error messages
<?php if ($success || $error): ?>
setTimeout(() => {
    const alert = document.querySelector('.alert');
    if (alert) {
        alert.style.transition = 'all 0.3s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }
}, 3000);
<?php endif; ?>

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s';
        document.body.style.opacity = '1';
    }, 100);
});
</script>

</body>
</html>