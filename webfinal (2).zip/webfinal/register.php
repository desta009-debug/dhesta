<?php
session_start();
require 'config.php';

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'pembeli') {
        header("Location: dashboard_pembeli.php");
    } else {
        header("Location: dashboard_staff.php");
    }
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = clean_input($_POST['nama'] ?? '');
    $email = clean_input($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Validasi
    if (empty($nama)) {
        $error = "❌ Nama tidak boleh kosong!";
    } elseif (empty($email)) {
        $error = "❌ Email tidak boleh kosong!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ Format email tidak valid!";
    } elseif (empty($password)) {
        $error = "❌ Password tidak boleh kosong!";
    } elseif ($password !== $password_confirm) {
        $error = "❌ Password tidak cocok!";
    } else {
        // Cek email sudah terdaftar dengan prepared statement
        $stmt_check = $conn->prepare("SELECT id_user FROM users WHERE email = ?");
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        
        if ($result->num_rows > 0) {
            $error = "❌ Email sudah terdaftar!";
        } else {
            // Insert user baru dengan password plain text (tanpa hashing)
            $stmt = $conn->prepare("INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, ?)");
            
            if ($stmt) {
                $stmt->bind_param("ssss", $nama, $email, $password, $role);
                $role = 'pembeli';
                
                if ($stmt->execute()) {
                    $success = "✅ Pendaftaran berhasil! Silakan login.";
                    $_POST = []; // Clear form
                } else {
                    $error = "❌ Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = "❌ Error persiapan query: " . $conn->error;
            }
        }
        $stmt_check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Reborn Garage</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 450px;
        }

        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo h1 {
            color: #667eea;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .logo p {
            color: #999;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.3s;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .password-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .password-group .form-group {
            margin-bottom: 0;
        }

        .password-group .form-group input {
            padding: 12px;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid;
            font-size: 14px;
        }

        .alert-error {
            background: #ffebee;
            color: #c62828;
            border-left-color: #f44336;
        }

        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left-color: #4caf50;
        }

        .btn {
            width: 100%;
            padding: 12px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .btn:active {
            transform: translateY(0);
        }

        .divider {
            text-align: center;
            color: #999;
            margin: 20px 0;
            font-size: 14px;
        }

        .login-link {
            text-align: center;
            color: #666;
            font-size: 14px;
        }

        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
        }

        .login-link a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        .info-box {
            background: #f5f5f5;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;
            border-left: 4px solid #667eea;
        }

        @media (max-width: 480px) {
            .card {
                padding: 30px 20px;
            }

            .password-group {
                grid-template-columns: 1fr;
            }

            .logo h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="logo">
                <h1>🚗 Reborn Garage</h1>
                <p>Daftar Sebagai Pembeli</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
                <div style="text-align: center; margin: 20px 0;">
                    <p style="color: #666; margin-bottom: 15px;">Anda akan diarahkan ke halaman login dalam 3 detik...</p>
                    <script>
                        setTimeout(() => {
                            window.location.href = 'login.php';
                        }, 3000);
                    </script>
                </div>
            <?php endif; ?>

            <form method="POST" action="register.php">
                <div class="info-box">
                    ℹ️ Daftar akun baru untuk mulai berbelanja di Reborn Garage
                </div>

                <div class="form-group">
                    <label for="nama">📝 Nama Lengkap *</label>
                    <input type="text" id="nama" name="nama" placeholder="Masukkan nama lengkap" value="<?php echo $_POST['nama'] ?? ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">📧 Email *</label>
                    <input type="email" id="email" name="email" placeholder="Masukkan email" value="<?php echo $_POST['email'] ?? ''; ?>" required>
                </div>

                <div class="password-group">
                    <div class="form-group">
                        <label for="password">🔐 Password *</label>
                        <input type="password" id="password" name="password" placeholder="Min. 6 karakter" required>
                    </div>
                    <div class="form-group">
                        <label for="password_confirm">🔐 Konfirmasi Password *</label>
                        <input type="password" id="password_confirm" name="password_confirm" placeholder="Ulangi password" required>
                    </div>
                </div>

                <button type="submit" class="btn">✅ Daftar Sekarang</button>
            </form>

            <div class="divider">Sudah punya akun?</div>

            <div class="login-link">
                <a href="login.php">← Kembali ke Login</a>
            </div>
        </div>
    </div>
</body>
</html>
