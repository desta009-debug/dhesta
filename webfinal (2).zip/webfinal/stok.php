<?php
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

// Ambil data user dari session
$nama = $_SESSION['nama'];
$role = $_SESSION['role'];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = clean_input($_GET['delete']);
    $delete_query = "DELETE FROM produk WHERE id_produk = '$id'";
    if (mysqli_query($conn, $delete_query)) {
        $success = "Produk berhasil dihapus!";
    } else {
        $error = "Gagal menghapus produk!";
    }
}

// Handle Add/Edit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_produk = clean_input($_POST['id_produk']);
    $nama_produk = clean_input($_POST['nama_produk']);
    $stok = clean_input($_POST['stok']);
    $nama_supplier = clean_input($_POST[ 'nama_supplier']);
    
    if (isset($_POST['edit_id']) && !empty($_POST['edit_id'])) {
        // Update
        $edit_id = clean_input($_POST['edit_id']);
        $update_query = "UPDATE produk SET 
            id_produk = '$id_produk',
            nama_produk = '$nama_produk',
            stok = '$stok',
            nama_supplier = '$nama_supplier'
            WHERE id_produk = '$edit_id'";
        
        if (mysqli_query($conn, $update_query)) {
            $success = "Produk berhasil diupdate!";
        } else {
            $error = "Gagal mengupdate produk!";
        }
    } else {
        // Insert
        $insert_query = "INSERT INTO produk (id_produk, nama_produk, stok, nama_supplier) 
                        VALUES ('$id_produk', '$nama_produk', '$stok', '$nama_supplier')";
        
        if (mysqli_query($conn, $insert_query)) {
            $success = "Produk berhasil ditambahkan!";
        } else {
            $error = "Gagal menambahkan produk! ID mungkin sudah ada.";
        }
    }
}

// Search functionality
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';
$where_clause = $search ? "WHERE nama_produk LIKE '%$search%' OR nama_supplier LIKE '%$search%' OR id_produk LIKE '%$search%'" : '';

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Get total records
$count_query = "SELECT COUNT(*) as total FROM produk $where_clause";
$count_result = mysqli_query($conn, $count_query);
$total_records = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_records / $limit);

// Query untuk mengambil data produk
$query_produk = "SELECT * FROM produk $where_clause ORDER BY id_produk ASC LIMIT $limit OFFSET $offset";
$result_produk = mysqli_query($conn, $query_produk);

// Get data for edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $edit_id = clean_input($_GET['edit']);
    $edit_query = "SELECT * FROM produk WHERE id_produk = '$edit_id'";
    $edit_result = mysqli_query($conn, $edit_query);
    $edit_data = mysqli_fetch_assoc($edit_result);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stok Persediaan - REBORN GARAGE</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* SIDEBAR - Same as dashboard */
        .sidebar {
            width: 280px;
            background: rgba(44, 62, 80, 0.95);
            backdrop-filter: blur(10px);
            color: #ecf0f1;
            padding: 25px;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="%23ffffff" fill-opacity="0.05" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
            opacity: 0.3;
        }

        .logo-title {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
            z-index: 1;
        }

        .logo-title img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            margin-bottom: 15px;
            border: 4px solid #667eea;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .logo-title h2 {
            font-size: 22px;
            font-weight: 700;
            color: #ecf0f1;
            margin-bottom: 5px;
        }

        .user-panel {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            background: rgba(52, 73, 94, 0.8);
            padding: 15px;
            border-radius: 12px;
            position: relative;
            z-index: 1;
            transition: transform 0.3s;
        }

        .user-panel:hover {
            transform: translateX(5px);
        }

        .user-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 12px;
            font-size: 22px;
            color: white;
            box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
        }

        .user-info {
            flex: 1;
        }

        .user-info .name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 3px;
        }

        .user-info .role {
            font-size: 12px;
            color: #bdc3c7;
            text-transform: uppercase;
        }

        .menu {
            position: relative;
            z-index: 1;
        }

        .menu button {
            display: block;
            width: 100%;
            padding: 14px 20px;
            margin-bottom: 12px;
            background: rgba(52, 73, 94, 0.6);
            border: none;
            border-radius: 10px;
            text-align: left;
            font-size: 15px;
            color: #ecf0f1;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .menu button.active {
            background: rgba(102, 126, 234, 0.5);
            padding-left: 25px;
        }

        .menu button.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .menu button:hover {
            background: rgba(102, 126, 234, 0.3);
            transform: translateX(5px);
            padding-left: 25px;
        }

        .logout-btn {
            margin-top: auto;
            padding: 12px 20px;
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            z-index: 1;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(231, 76, 60, 0.4);
        }

        /* MAIN CONTENT */
        .main-content {
            flex: 1;
            padding: 30px;
            background: rgba(255, 255, 255, 0.95);
            overflow-y: auto;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #ecf0f1;
        }

        .page-header h1 {
            font-size: 32px;
            color: #2c3e50;
            font-weight: 700;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-success {
            background: linear-gradient(135deg, #27ae60, #229954);
            color: white;
        }

        .btn-warning {
            background: linear-gradient(135deg, #f39c12, #e67e22);
            color: white;
        }

        .btn-danger {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
        }

        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }

        .alert {
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            font-size: 15px;
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #27ae60;
            color: #155724;
        }

        .alert-error {
            background: #f8d7da;
            border-left: 4px solid #e74c3c;
            color: #721c24;
        }

        .search-box {
            margin-bottom: 25px;
        }

        .search-box input {
            width: 100%;
            max-width: 400px;
            padding: 14px 20px;
            border: 2px solid #ecf0f1;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(5px);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal.show {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: slideUp 0.3s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #ecf0f1;
        }

        .modal-header h2 {
            font-size: 24px;
            color: #2c3e50;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #2c3e50;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ecf0f1;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        /* Table */
        .table-container {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        thead th {
            padding: 18px 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        tbody tr {
            border-bottom: 1px solid #ecf0f1;
            transition: all 0.3s;
        }

        tbody tr:hover {
            background: #f8f9fa;
            transform: scale(1.01);
        }

        tbody td {
            padding: 15px;
            color: #2c3e50;
            font-size: 14px;
        }

        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-success {
            background: #d4edda;
            color: #155724;
        }

        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }

        .badge-danger {
            background: #f8d7da;
            color: #721c24;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 25px;
        }

        .pagination a {
            padding: 10px 16px;
            border-radius: 8px;
            background: white;
            border: 2px solid #ecf0f1;
            color: #2c3e50;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .pagination a:hover {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-color: transparent;
        }

        .pagination a.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-color: transparent;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 600px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="logo-title">
                <div style="width: 85px; height: 85px; margin: 0 auto 15px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; color: white; border: 4px solid #667eea; box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4); animation: float 3s ease-in-out infinite;">RG</div>
                <h2>REBORN GARAGE</h2>
            </div>

            <div class="user-panel">
                <div class="user-icon">👤</div>
                <div class="user-info">
                    <div class="name">Halo, <?php echo htmlspecialchars($nama); ?></div>
                    <div class="role"><?php echo htmlspecialchars($role); ?></div>
                </div>
            </div>

            <nav class="menu">
                <button onclick="location.href='dashboard.php'">📊 Dashboard</button>
                <button class="active" onclick="location.href='stok.php'">📦 Stok Persediaan</button>
                <button onclick="location.href='barang_masuk.php'">📥 Data Barang Masuk</button>
                <button onclick="location.href='barang_keluar.php'">📤 Data Barang Keluar</button>
                <button onclick="location.href='laporan.php'">📄 Laporan</button>
            </nav>

            <button class="logout-btn" onclick="if(confirm('Yakin ingin logout?')) location.href='logout.php'">
                🚪 Logout
            </button>
        </aside>

        <!-- MAIN -->
        <main class="main-content">
            <div class="page-header">
                <h1>📦 Stok Persediaan</h1>
                <button class="btn btn-primary" onclick="openModal()">
                    ➕ Tambah Produk
                </button>
            </div>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="search-box">
                <form method="GET" action="">
                    <input type="text" name="search" placeholder="🔍 Cari produk, supplier, atau ID..." value="<?php echo htmlspecialchars($search); ?>">
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID Produk</th>
                            <th>Nama Produk</th>
                            <th>Stok</th>
                            <th>Supplier</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($produk = mysqli_fetch_assoc($result_produk)): 
                            $stok_status = $produk['stok'] > 50 ? 'success' : ($produk['stok'] > 20 ? 'warning' : 'danger');
                            $stok_text = $produk['stok'] > 50 ? 'Stok Aman' : ($produk['stok'] > 20 ? 'Stok Menipis' : 'Stok Habis');
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($produk['id_produk']); ?></strong></td>
                            <td><?php echo htmlspecialchars($produk['nama_produk']); ?></td>
                            <td><strong><?php echo $produk['stok']; ?></strong> unit</td>
                            <td><?php echo htmlspecialchars($produk['nama_supplier']); ?></td>
                            <td><span class="badge badge-<?php echo $stok_status; ?>"><?php echo $stok_text; ?></span></td>
                            <td>
                                <button class="btn btn-warning btn-sm" onclick="editProduk(<?php echo htmlspecialchars(json_encode($produk)); ?>)">✏️ Edit</button>
                                <button class="btn btn-danger btn-sm" onclick="if(confirm('Yakin ingin menghapus?')) location.href='?delete=<?php echo $produk['id_produk']; ?>'">🗑️ Hapus</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page-1; ?>&search=<?php echo $search; ?>">← Previous</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>" class="<?php echo $i == $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page+1; ?>&search=<?php echo $search; ?>">Next →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Tambah Produk</h2>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="edit_id" id="edit_id">
                
                <div class="form-group">
                    <label>ID Produk</label>
                    <input type="text" name="id_produk" id="id_produk" required>
                </div>

                <div class="form-group">
                    <label>Nama Produk</label>
                    <input type="text" name="nama_produk" id="nama_produk" required>
                </div>

                <div class="form-group">
                    <label>Stok</label>
                    <input type="number" name="stok" id="stok" required min="0">
                </div>

                <div class="form-group">
                    <label>Nama Supplier</label>
                    <input type="text" name="nama_supplier" id="nama_supplier" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-success">💾 Simpan</button>
                    <button type="button" class="btn btn-danger" onclick="closeModal()">❌ Batal</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('productModal').classList.add('show');
            document.getElementById('modalTitle').textContent = 'Tambah Produk';
            document.getElementById('edit_id').value = '';
            document.getElementById('id_produk').value = '';
            document.getElementById('nama_produk').value = '';
            document.getElementById('stok').value = '';
            document.getElementById('nama_supplier').value = '';
            document.getElementById('id_produk').readOnly = false;
        }

        function closeModal() {
            document.getElementById('productModal').classList.remove('show');
        }

        function editProduk(data) {
            document.getElementById('productModal').classList.add('show');
            document.getElementById('modalTitle').textContent = 'Edit Produk';
            document.getElementById('edit_id').value = data.id_produk;
            document.getElementById('id_produk').value = data.id_produk;
            document.getElementById('nama_produk').value = data.nama_produk;
            document.getElementById('stok').value = data.stok;
            document.getElementById('nama_supplier').value = data.nama_supplier;
            document.getElementById('id_produk').readOnly = true;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('productModal');
            if (event.target == modal) {
                closeModal();
            }
        }

        <?php if ($edit_data): ?>
        // Auto open modal if edit parameter exists
        editProduk(<?php echo json_encode($edit_data); ?>);
        <?php endif; ?>
    </script>
</body>
</html>