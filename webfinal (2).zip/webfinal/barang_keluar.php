<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Staff';

// Get filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Build query with filter
$filter_condition = "";
if ($filter == 'penjualan') {
    $filter_condition = " WHERE bk.keterangan LIKE 'Pesanan #%'";
} elseif ($filter == 'lainnya') {
    $filter_condition = " WHERE (bk.keterangan NOT LIKE 'Pesanan #%' OR bk.keterangan IS NULL)";
}

// Get barang keluar with product info
$query = "
    SELECT bk.*, p.nama_produk, p.gambar, p.harga 
    FROM barang_keluar bk 
    LEFT JOIN produk p ON bk.id_produk = p.id_produk 
    $filter_condition
    ORDER BY bk.tanggal DESC, bk.id_barang_keluar DESC
";
$result = mysqli_query($conn, $query);

// Calculate statistics
$stats_query = "
    SELECT 
        COUNT(DISTINCT bk.id_barang_keluar) as total_transaksi,
        SUM(bk.jumlah) as total_item_keluar,
        COUNT(DISTINCT bk.id_produk) as produk_berbeda,
        SUM(CASE WHEN bk.keterangan LIKE 'Pesanan #%' THEN 1 ELSE 0 END) as dari_penjualan,
        SUM(CASE WHEN bk.keterangan LIKE 'Pesanan #%' THEN bk.jumlah ELSE 0 END) as item_penjualan
    FROM barang_keluar bk
";
$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Barang Keluar - Reborn Garage</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== PAGE HEADER ========== */
.page-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.page-header h1 {
    font-size: 36px;
    margin-bottom: 8px;
    font-weight: 700;
}

.page-header p {
    font-size: 16px;
    opacity: 0.9;
}

/* ========== STATS CARDS ========== */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.12);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
}

.stat-icon.danger { background: linear-gradient(135deg, #f44336, #ef5350); }
.stat-icon.warning { background: linear-gradient(135deg, #ff9800, #fb8c00); }
.stat-icon.info { background: linear-gradient(135deg, #1e88e5, #42a5f5); }
.stat-icon.success { background: linear-gradient(135deg, #4caf50, #66bb6a); }
.stat-icon.purple { background: linear-gradient(135deg, #9c27b0, #ba68c8); }

.stat-details h3 {
    font-size: 14px;
    color: #666;
    margin-bottom: 5px;
    font-weight: 500;
}

.stat-details .stat-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary);
}

.stat-details .stat-sub {
    font-size: 12px;
    color: var(--accent);
    margin-top: 3px;
    font-weight: 600;
}

/* ========== FILTER SECTION ========== */
.filter-section {
    background: white;
    padding: 25px;
    border-radius: 16px;
    margin-bottom: 30px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.filter-buttons {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 12px 24px;
    border: 2px solid #e0e0e0;
    background: white;
    color: #666;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.filter-btn:hover {
    border-color: var(--accent);
    color: var(--accent);
    transform: translateY(-2px);
}

.filter-btn.active {
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    border-color: var(--accent);
}

/* ========== TABLE SECTION ========== */
.table-section {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.table-header h2 {
    font-size: 24px;
    color: var(--primary);
    font-weight: 700;
}

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background: linear-gradient(135deg, #f5f5f5, #fafafa);
}

th {
    padding: 15px 12px;
    text-align: left;
    font-weight: 600;
    color: var(--primary);
    font-size: 14px;
    border-bottom: 2px solid #e0e0e0;
}

td {
    padding: 15px 12px;
    border-bottom: 1px solid #f0f0f0;
    color: #333;
    font-size: 14px;
}

tbody tr {
    transition: all 0.2s;
}

tbody tr:hover {
    background: #f9f9f9;
}

/* ========== PRODUCT IMAGE IN TABLE ========== */
.product-cell {
    display: flex;
    align-items: center;
    gap: 12px;
}

.product-image {
    width: 50px;
    height: 50px;
    border-radius: 8px;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    flex-shrink: 0;
    border: 2px solid #e0e0e0;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.product-image .placeholder {
    font-size: 24px;
}

.product-info {
    display: flex;
    flex-direction: column;
}

.product-name {
    font-weight: 600;
    color: var(--primary);
    margin-bottom: 3px;
}

.product-price {
    font-size: 12px;
    color: var(--accent);
    font-weight: 500;
}

/* ========== BADGES ========== */
.badge {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
}

.badge-tujuan {
    background: linear-gradient(135deg, var(--info), #42a5f5);
    color: white;
}

.badge-penjualan {
    background: linear-gradient(135deg, var(--success), #66bb6a);
    color: white;
}

.qty-badge {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
    padding: 8px 14px;
    border-radius: 8px;
    font-weight: 700;
}

/* ========== ORDER LINK ========== */
.order-link {
    color: var(--info);
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: all 0.3s;
}

.order-link:hover {
    color: var(--primary);
    text-decoration: underline;
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-icon {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-state h3 {
    font-size: 22px;
    color: var(--primary);
    margin-bottom: 8px;
}

.empty-state p {
    color: #666;
    font-size: 14px;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header h1 {
        font-size: 28px;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .filter-buttons {
        flex-direction: column;
    }
    
    .filter-btn {
        width: 100%;
    }
    
    .table-wrapper {
        overflow-x: scroll;
    }
    
    table {
        min-width: 900px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👤</span>
            <span class="badge-text"><?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_staff.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="data_produk.php">
            <span class="icon">📦</span>
            <span>Kelola Produk</span>
        </a>
        <a href="kategori.php">
            <span class="icon">🏷️</span>
            <span>Kategori</span>
        </a>
        <a href="supplier.php">
            <span class="icon">🏭</span>
            <span>Supplier</span>
        </a>
        <a href="barang_masuk.php">
            <span class="icon">📥</span>
            <span>Barang Masuk</span>
        </a>
        <a href="barang_keluar.php" class="active">
            <span class="icon">📤</span>
            <span>Barang Keluar</span>
        </a>
        <a href="kelola_pesanan.php">
            <span class="icon">📋</span>
            <span>Kelola Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h1>📤 Barang Keluar</h1>
        <p>Monitor dan kelola data barang yang keluar dari inventory (terintegrasi dengan pesanan)</p>
    </div>

    <!-- STATISTICS CARDS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon danger">📤</div>
            <div class="stat-details">
                <h3>Total Transaksi Keluar</h3>
                <div class="stat-value"><?= number_format($stats['total_transaksi'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon warning">📊</div>
            <div class="stat-details">
                <h3>Total Item Keluar</h3>
                <div class="stat-value"><?= number_format($stats['total_item_keluar'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon info">🏷️</div>
            <div class="stat-details">
                <h3>Produk Berbeda</h3>
                <div class="stat-value"><?= number_format($stats['produk_berbeda'] ?? 0) ?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon success">🛒</div>
            <div class="stat-details">
                <h3>Dari Penjualan</h3>
                <div class="stat-value"><?= number_format($stats['dari_penjualan'] ?? 0) ?></div>
                <div class="stat-sub"><?= number_format($stats['item_penjualan'] ?? 0) ?> item terjual</div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon purple">📦</div>
            <div class="stat-details">
                <h3>Lainnya</h3>
                <div class="stat-value"><?= number_format(($stats['total_transaksi'] ?? 0) - ($stats['dari_penjualan'] ?? 0)) ?></div>
                <div class="stat-sub">Transfer, retur, dll</div>
            </div>
        </div>
    </div>

    <!-- FILTER SECTION -->
    <div class="filter-section">
        <div class="filter-buttons">
            <a href="?filter=all" class="filter-btn <?= $filter == 'all' ? 'active' : '' ?>">
                📊 Semua Barang Keluar
            </a>
            <a href="?filter=penjualan" class="filter-btn <?= $filter == 'penjualan' ? 'active' : '' ?>">
                🛒 Penjualan Online
            </a>
            <a href="?filter=lainnya" class="filter-btn <?= $filter == 'lainnya' ? 'active' : '' ?>">
                📦 Lainnya (Transfer, Retur, dll)
            </a>
        </div>
    </div>

    <!-- TABLE SECTION -->
    <div class="table-section">
        <div class="table-header">
            <h2>📋 Riwayat Barang Keluar</h2>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th style="width: 60px;">#</th>
                        <th style="width: 120px;">Tanggal</th>
                        <th style="min-width: 250px;">Produk</th>
                        <th style="width: 100px; text-align: center;">Jumlah</th>
                        <th style="width: 180px;">Tujuan</th>
                        <th style="min-width: 200px;">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($row['id_barang_keluar']) ?></strong></td>
                                <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                                <td>
                                    <div class="product-cell">
                                        <div class="product-image">
                                            <?php if (!empty($row['gambar'])): ?>
                                                <img src="uploads/<?= htmlspecialchars($row['gambar']) ?>" alt="<?= htmlspecialchars($row['nama_produk']) ?>">
                                            <?php else: ?>
                                                <span class="placeholder">📦</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-info">
                                            <div class="product-name"><?= htmlspecialchars($row['nama_produk'] ?? 'N/A') ?></div>
                                            <?php if (!empty($row['harga'])): ?>
                                                <div class="product-price">Rp <?= number_format($row['harga'], 0, ',', '.') ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td style="text-align: center;">
                                    <span class="qty-badge"><?= number_format($row['jumlah']) ?></span>
                                </td>
                                <td>
                                    <?php 
                                    $is_penjualan = strpos($row['keterangan'] ?? '', 'Pesanan #') === 0;
                                    $badge_class = $is_penjualan ? 'badge-penjualan' : 'badge-tujuan';
                                    ?>
                                    <span class="badge <?= $badge_class ?>">
                                        <?= htmlspecialchars($row['tujuan'] ?? '-') ?>
                                    </span>
                                </td>
                                <td>
                                    <?php 
                                    $ket = htmlspecialchars($row['keterangan'] ?? '-');
                                    // Jika keterangan berisi "Pesanan #", buat link ke halaman kelola pesanan
                                    if (preg_match('/Pesanan #(\d+)/', $ket, $matches)) {
                                        $id_pesanan = $matches[1];
                                        echo '<a href="kelola_pesanan.php?status=all#order-' . $id_pesanan . '" class="order-link" title="Lihat detail pesanan">';
                                        echo '🔗 ' . $ket;
                                        echo '</a>';
                                    } else {
                                        echo '<span style="color: #666;">' . $ket . '</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <div class="empty-icon">📭</div>
                                    <h3>Belum Ada Data Barang Keluar</h3>
                                    <p>Riwayat barang keluar akan muncul di sini setelah pesanan diselesaikan</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Smooth page load animation
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s';
        document.body.style.opacity = '1';
    }, 100);
});

// Animate stat cards on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '0';
            entry.target.style.transform = 'translateY(20px)';
            setTimeout(() => {
                entry.target.style.transition = 'all 0.5s ease-out';
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }, 100);
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.stat-card').forEach(card => {
    observer.observe(card);
});

// Highlight row if coming from order link
if (window.location.hash) {
    const hash = window.location.hash.substring(1);
    if (hash.startsWith('order-')) {
        setTimeout(() => {
            const orderId = hash.replace('order-', '');
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const ket = row.querySelector('td:last-child a');
                if (ket && ket.textContent.includes('#' + orderId)) {
                    row.style.background = '#fff3e0';
                    row.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => {
                        row.style.transition = 'background 1s';
                        row.style.background = '';
                    }, 2000);
                }
            });
        }, 500);
    }
}
</script>

</body>
</html>