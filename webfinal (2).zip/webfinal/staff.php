<?php
require_once 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

// Ambil data user dari session
$nama = $_SESSION['nama'];
$role = $_SESSION['role'];

// Query untuk mengambil data produk
$query_produk = "SELECT * FROM produk ORDER BY id_produk ASC LIMIT 9";
$result_produk = mysqli_query($conn, $query_produk);

// Query untuk statistik
$query_total_produk = "SELECT COUNT(*) as total FROM produk";
$total_produk = mysqli_fetch_assoc(mysqli_query($conn, $query_total_produk))['total'];

$query_total_stok = "SELECT SUM(stok) as total FROM produk";
$total_stok = mysqli_fetch_assoc(mysqli_query($conn, $query_total_stok))['total'];

$query_barang_masuk = "SELECT COUNT(*) as total FROM barang_masuk WHERE MONTH(tanggal) = MONTH(CURDATE())";
$barang_masuk_bulan_ini = mysqli_fetch_assoc(mysqli_query($conn, $query_barang_masuk))['total'];

$query_barang_keluar = "SELECT COUNT(*) as total FROM barang_keluar WHERE MONTH(tanggal) = MONTH(CURDATE())";
$barang_keluar_bulan_ini = mysqli_fetch_assoc(mysqli_query($conn, $query_barang_keluar))['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - REBORN GARAGE</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* SIDEBAR */
        .sidebar {
            width: 280px;
            background: rgba(44, 62, 80, 0.95);
            backdrop-filter: blur(10px);
            color: #ecf0f1;
            padding: 25px;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="%23ffffff" fill-opacity="0.05" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
            opacity: 0.3;
        }

        .logo-title {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
            z-index: 1;
        }

        .logo-title img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            margin-bottom: 15px;
            border: 4px solid #667eea;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .logo-title h2 {
            font-size: 22px;
            font-weight: 700;
            color: #ecf0f1;
            margin-bottom: 5px;
        }

        .user-panel {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            background: rgba(52, 73, 94, 0.8);
            padding: 15px;
            border-radius: 12px;
            position: relative;
            z-index: 1;
            transition: transform 0.3s;
        }

        .user-panel:hover {
            transform: translateX(5px);
        }

        .user-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 12px;
            font-size: 22px;
            color: white;
            box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
        }

        .user-info {
            flex: 1;
        }

        .user-info .name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 3px;
        }

        .user-info .role {
            font-size: 12px;
            color: #bdc3c7;
            text-transform: uppercase;
        }

        .menu {
            position: relative;
            z-index: 1;
        }

        .menu button {
            display: block;
            width: 100%;
            padding: 14px 20px;
            margin-bottom: 12px;
            background: rgba(52, 73, 94, 0.6);
            border: none;
            border-radius: 10px;
            text-align: left;
            font-size: 15px;
            color: #ecf0f1;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .menu button::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            transform: scaleY(0);
            transition: transform 0.3s;
        }

        .menu button:hover {
            background: rgba(102, 126, 234, 0.3);
            transform: translateX(5px);
            padding-left: 25px;
        }

        .menu button:hover::before {
            transform: scaleY(1);
        }

        .logout-btn {
            margin-top: auto;
            padding: 12px 20px;
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            z-index: 1;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(231, 76, 60, 0.4);
        }

        /* MAIN CONTENT */
        .main-content {
            flex: 1;
            padding: 30px;
            background: rgba(255, 255, 255, 0.95);
            overflow-y: auto;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.2);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 15px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            color: #7f8c8d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .dashboard {
            text-align: center;
            margin-bottom: 40px;
        }

        .dashboard h2 {
            font-size: 32px;
            color: #2c3e50;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .dashboard p {
            color: #7f8c8d;
            font-size: 16px;
        }

        .product-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .product-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .product-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.1), transparent);
            transition: left 0.5s;
        }

        .product-card:hover::before {
            left: 100%;
        }

        .product-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.3);
        }

        .product-card img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 12px;
            margin-bottom: 15px;
            border: 3px solid #f8f9fa;
            transition: transform 0.3s;
        }

        .product-card:hover img {
            transform: scale(1.1) rotate(5deg);
        }

        .product-card h3 {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 8px;
        }

        .product-stock {
            display: inline-block;
            padding: 6px 15px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .product-supplier {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 8px;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                padding: 15px;
            }

            .main-content {
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .product-cards {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="logo-title">
                <div style="width: 85px; height: 85px; margin: 0 auto 15px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; color: white; border: 4px solid #667eea; box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4); animation: float 3s ease-in-out infinite;">RG</div>
                <h2>REBORN GARAGE</h2>
            </div>

            <div class="user-panel">
                <div class="user-icon">👤</div>
                <div class="user-info">
                    <div class="name">Halo, <?php echo htmlspecialchars($nama); ?></div>
                    <div class="role"><?php echo htmlspecialchars($role); ?></div>
                </div>
            </div>

            <nav class="menu">
                <button onclick="location.href='dashboard.php'">📊 Dashboard</button>
                <button onclick="location.href='stok.php'">📦 Stok Persediaan</button>
                <button onclick="location.href='barang_masuk.php'">📥 Data Barang Masuk</button>
                <button onclick="location.href='barang_keluar.php'">📤 Data Barang Keluar</button>
                <button onclick="location.href='laporan.php'">📄 Laporan</button>
            </nav>

            <button class="logout-btn" onclick="if(confirm('Yakin ingin logout?')) location.href='logout.php'">
                🚪 Logout
            </button>
        </aside>

        <!-- MAIN -->
        <main class="main-content">
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-value"><?php echo $total_produk; ?></div>
                    <div class="stat-label">Total Produk</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value"><?php echo number_format($total_stok); ?></div>
                    <div class="stat-label">Total Stok</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📥</div>
                    <div class="stat-value"><?php echo $barang_masuk_bulan_ini; ?></div>
                    <div class="stat-label">Barang Masuk (Bulan Ini)</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📤</div>
                    <div class="stat-value"><?php echo $barang_keluar_bulan_ini; ?></div>
                    <div class="stat-label">Barang Keluar (Bulan Ini)</div>
                </div>
            </div>

            <section class="dashboard">
                <h2>Sistem Informasi Inventory</h2>
                <p>REBORN GARAGE - Manage Your Inventory Efficiently</p>

                <div class="product-cards">
                    <?php while($produk = mysqli_fetch_assoc($result_produk)): ?>
                        <div class="product-card">
                            <div style="width: 120px; height: 120px; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 12px; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 40px; font-weight: bold;">
                                <?php echo strtoupper(substr($produk['nama_produk'], 0, 2)); ?>
                            </div>
                            <h3><?php echo htmlspecialchars($produk['nama_produk']); ?></h3>
                            <span class="product-stock">Stok: <?php echo $produk['stok']; ?></span>
                            <p class="product-supplier"><?php echo htmlspecialchars($produk['nama_supplier']); ?></p>
                        </div>
                    <?php endwhile; ?>
                </div>
            </section>
        </main>
    </div>
</body>
</html>