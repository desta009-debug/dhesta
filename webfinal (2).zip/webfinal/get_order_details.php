<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    die("Unauthorized");
}

$id_order = (int)$_GET['id'];

$order = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT o.*, u.nama, u.email 
    FROM orders o 
    JOIN users u ON o.id_user = u.id_user 
    WHERE o.id_order = $id_order
"));

if (!$order) {
    die("Order not found");
}

$items = mysqli_query($conn, "
    SELECT oi.*, p.nama_produk 
    FROM order_items oi 
    JOIN produk p ON oi.id_produk = p.id_produk 
    WHERE oi.id_order = $id_order
");
?>

<style>
.detail-row {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid #f0f0f0;
}

.detail-label {
    font-weight: 600;
    color: #666;
}

.detail-value {
    color: #1e1e2f;
    font-weight: 500;
}

.status-badge {
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 700;
    display: inline-block;
    text-transform: uppercase;
}

.status-pending {
    background: linear-gradient(135deg, #fff3e0, #ffe0b2);
    color: #e65100;
}

.status-processing {
    background: linear-gradient(135deg, #e3f2fd, #bbdefb);
    color: #0d47a1;
}

.status-completed {
    background: linear-gradient(135deg, #c8e6c9, #a5d6a7);
    color: #1b5e20;
}

.status-cancelled {
    background: linear-gradient(135deg, #ffcdd2, #ef9a9a);
    color: #b71c1c;
}

.items-section {
    margin: 20px 0;
    border-top: 2px solid #eee;
    padding-top: 15px;
}

.items-section h3 {
    margin-bottom: 15px;
    color: #1e1e2f;
    font-size: 18px;
}

.total-row {
    border: none;
    font-size: 18px;
    font-weight: bold;
    color: #43a047;
    padding-top: 15px;
    margin-top: 10px;
    border-top: 2px solid #43a047;
}

.form-group {
    margin-top: 25px;
    padding-top: 20px;
    border-top: 2px solid #f0f0f0;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 10px;
    color: #1e1e2f;
    font-size: 16px;
}

.form-group select {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    background: white;
    cursor: pointer;
    transition: all 0.3s;
}

.form-group select:focus {
    border-color: #43a047;
    outline: none;
    box-shadow: 0 0 0 3px rgba(67, 160, 71, 0.1);
}

.modal-actions {
    margin-top: 25px;
    display: flex;
    gap: 15px;
    justify-content: flex-end;
}

.btn {
    padding: 12px 30px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-primary {
    background: linear-gradient(135deg, #43a047, #4caf50);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #2e7d32, #388e3c);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(67, 160, 71, 0.3);
}

.btn-secondary {
    background: #e0e0e0;
    color: #333;
}

.btn-secondary:hover {
    background: #d0d0d0;
}
</style>

<div class="detail-row">
    <span class="detail-label">No. Pesanan:</span>
    <span class="detail-value">#<?php echo $order['id_order']; ?></span>
</div>

<div class="detail-row">
    <span class="detail-label">Pembeli:</span>
    <span class="detail-value"><?php echo htmlspecialchars($order['nama']); ?></span>
</div>

<div class="detail-row">
    <span class="detail-label">Email:</span>
    <span class="detail-value"><?php echo htmlspecialchars($order['email']); ?></span>
</div>

<div class="detail-row">
    <span class="detail-label">Metode Pembayaran:</span>
    <span class="detail-value">
        <?php
            $payment_label = [
                'transfer_bank' => '🏦 Transfer Bank',
                'e_wallet' => '📱 E-Wallet',
                'cicilan' => '💳 Cicilan',
                'cash' => '💵 Cash'
            ];
            echo $payment_label[$order['metode_pembayaran']] ?? $order['metode_pembayaran'];
        ?>
    </span>
</div>

<div class="detail-row">
    <span class="detail-label">Status:</span>
    <span class="detail-value">
        <span class="status-badge status-<?php echo $order['status']; ?>">
            <?php
                $status_label = [
                    'pending' => '⏳ Menunggu',
                    'processing' => '🔄 Diproses',
                    'completed' => '✓ Selesai',
                    'cancelled' => '✖ Dibatalkan'
                ];
                echo $status_label[$order['status']] ?? $order['status'];
            ?>
        </span>
    </span>
</div>

<div class="detail-row">
    <span class="detail-label">Tanggal:</span>
    <span class="detail-value"><?php echo date('d M Y H:i', strtotime($order['tanggal_order'])); ?></span>
</div>

<div class="items-section">
    <h3>📦 Item Pesanan:</h3>
    <?php while ($item = mysqli_fetch_assoc($items)): ?>
        <div class="detail-row">
            <span class="detail-label">
                <?php echo htmlspecialchars($item['nama_produk']); ?> 
                <strong>(<?php echo $item['jumlah']; ?> pcs)</strong>
            </span>
            <span class="detail-value">Rp <?php echo number_format($item['subtotal'], 0, ',', '.'); ?></span>
        </div>
    <?php endwhile; ?>
</div>

<div class="detail-row total-row">
    <span class="detail-label">TOTAL:</span>
    <span class="detail-value">Rp <?php echo number_format($order['total_harga'], 0, ',', '.'); ?></span>
</div>

<!-- FORM UPDATE STATUS -->
<form method="POST" action="kelola_pesanan.php" id="updateStatusForm">
    <input type="hidden" name="id_order" value="<?php echo $order['id_order']; ?>">
    
    <div class="form-group">
        <label for="status">🔄 Update Status Pesanan:</label>
        <select name="status" id="status" required>
            <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>
                ⏳ Menunggu
            </option>
            <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>
                🔄 Diproses
            </option>
            <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>
                ✓ Selesai
            </option>
            <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>
                ✖ Dibatalkan
            </option>
        </select>
    </div>
    
    <div class="modal-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">
            ❌ Batal
        </button>
        <button type="submit" name="update_status" class="btn btn-primary">
            💾 Update Status
        </button>
    </div>
</form>