<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pembeli') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Pembeli';

// Handle add to cart
$add_success = "";
$add_error = "";

if (isset($_POST['add_to_cart'])) {
    $id_produk = clean_input($_POST['id_produk']);
    $jumlah = clean_input($_POST['jumlah']);
    
    // Validasi jumlah
    if (!is_numeric($jumlah) || $jumlah < 1) {
        $add_error = "Jumlah tidak valid!";
    } else {
        // Cek stok
        $stok_query = mysqli_query($conn, "SELECT stok FROM produk WHERE id_produk = $id_produk");
        $stok_data = mysqli_fetch_assoc($stok_query);
        
        if ($stok_data['stok'] < $jumlah) {
            $add_error = "Stok tidak cukup! Stok tersedia: " . $stok_data['stok'];
        } else {
            // Cek apakah produk sudah di keranjang
            $cart_check = mysqli_query($conn, "SELECT * FROM keranjang WHERE id_user = $id_user AND id_produk = $id_produk");
            
            if (mysqli_num_rows($cart_check) > 0) {
                // Update jumlah
                $existing = mysqli_fetch_assoc($cart_check);
                $new_qty = $existing['jumlah'] + $jumlah;
                
                if ($stok_data['stok'] < $new_qty) {
                    $add_error = "Stok tidak cukup untuk jumlah tersebut!";
                } else {
                    mysqli_query($conn, "UPDATE keranjang SET jumlah = $new_qty WHERE id_user = $id_user AND id_produk = $id_produk");
                    $add_success = "✅ Produk berhasil ditambahkan ke keranjang!";
                }
            } else {
                // Insert ke keranjang
                $insert = mysqli_query($conn, "INSERT INTO keranjang (id_user, id_produk, jumlah) VALUES ($id_user, $id_produk, $jumlah)");
                if ($insert) {
                    $add_success = "✅ Produk berhasil ditambahkan ke keranjang!";
                } else {
                    $add_error = "Terjadi kesalahan saat menambahkan ke keranjang!";
                }
            }
        }
    }
}

// Query produk dengan JOIN
$data = mysqli_query($conn, "
    SELECT 
        p.id_produk,
        p.nama_produk,
        p.harga,
        p.stok,
        p.gambar,
        k.nama_kategori,
        s.nama_supplier
    FROM produk p
    LEFT JOIN kategori k ON p.id_kategori = k.id_kategori
    LEFT JOIN suppliers s ON p.id_supplier = s.id_supplier
    WHERE p.stok > 0
    ORDER BY p.nama_produk ASC
");

if (!$data) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Belanja Produk - Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.sidebar.small .logo-image {
    width: 50px;
    height: 50px;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
    position: relative;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== HEADER ========== */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 35px;
    flex-wrap: wrap;
    gap: 20px;
}

.header h2 {
    color: var(--primary);
    font-size: 32px;
    font-weight: 700;
}

/* ========== ALERT ========== */
.alert {
    padding: 16px 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.alert-success {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
    border-left: 4px solid var(--success);
}

.alert-error {
    background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%);
    color: #b71c1c;
    border-left: 4px solid var(--danger);
}

/* ========== PRODUCT GRID ========== */
.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
}

/* ========== PRODUCT CARD ========== */
.product-card {
    background: white;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    display: flex;
    flex-direction: column;
}

.product-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.product-image {
    width: 100%;
    height: 200px;
    background: linear-gradient(135deg, #f5f5f5 0%, #e0e0e0 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
    overflow: hidden;
    position: relative;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.product-image-placeholder {
    font-size: 64px;
    opacity: 0.5;
}

.product-info {
    padding: 20px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.product-name {
    font-size: 16px;
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 8px;
    line-height: 1.4;
}

.product-category {
    font-size: 12px;
    color: #999;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
}

.product-price {
    font-size: 22px;
    font-weight: 700;
    color: var(--accent);
    margin-bottom: 12px;
}

.product-stock {
    font-size: 13px;
    color: #666;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #f0f0f0;
}

.stock-badge {
    display: inline-block;
    padding: 4px 10px;
    background: linear-gradient(135deg, var(--success) 0%, #66bb6a 100%);
    color: white;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.stock-badge.limited {
    background: linear-gradient(135deg, var(--warning) 0%, #ffb74d 100%);
}

/* ========== PRODUCT FORM ========== */
.product-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: auto;
}

.qty-input {
    display: flex;
    gap: 8px;
    margin-bottom: 12px;
}

.qty-input label {
    font-size: 12px;
    color: #666;
    text-transform: uppercase;
    font-weight: 600;
    width: 60px;
}

.qty-input input {
    flex: 1;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 13px;
}

.add-cart-btn {
    padding: 12px 16px;
    background: linear-gradient(135deg, var(--accent) 0%, #66bb6a 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    text-transform: uppercase;
    font-size: 13px;
    letter-spacing: 0.5px;
}

.add-cart-btn:hover {
    background: linear-gradient(135deg, #2e7d32 0%, #388e3c 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(67,160,71,0.3);
}

.add-cart-btn:active {
    transform: translateY(0);
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 80px 20px;
    grid-column: 1 / -1;
}

.empty-state .icon {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.3;
}

.empty-state p {
    font-size: 18px;
    color: #999;
    margin-bottom: 25px;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .sidebar .badge-content {
        justify-content: center;
        border-left: none;
        background: transparent;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .header h2 {
        font-size: 24px;
    }
    
    .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 15px;
    }
    
    .product-image {
        height: 150px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <!-- USER INFO -->
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👋</span>
            <span class="badge-text">Halo, <?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_pembeli.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="produk.php" class="active">
            <span class="icon">🛍️</span>
            <span>Belanja Produk</span>
        </a>
        <a href="keranjang.php">
            <span class="icon">🛒</span>
            <span>Keranjang</span>
        </a>
        <a href="riwayat_pesanan.php">
            <span class="icon">📋</span>
            <span>Riwayat Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- HEADER -->
    <div class="header">
        <h2>🛍️ Belanja Produk</h2>
    </div>

    <!-- ALERTS -->
    <?php if ($add_success): ?>
        <div class="alert alert-success">
            <span><?= $add_success; ?></span>
        </div>
    <?php endif; ?>

    <?php if ($add_error): ?>
        <div class="alert alert-error">
            <span><?= $add_error; ?></span>
        </div>
    <?php endif; ?>

    <!-- PRODUCTS GRID -->
    <div class="products-grid">
        <?php 
        if(mysqli_num_rows($data) > 0) {
            while($p = mysqli_fetch_assoc($data)) { 
                $harga_format = number_format($p['harga'], 0, ',', '.');
                $stok_class = $p['stok'] <= 10 ? 'limited' : '';
        ?>
        <div class="product-card">
            <div class="product-image">
                <?php if (!empty($p['gambar']) && file_exists('uploads/' . $p['gambar'])): ?>
                    <img src="uploads/<?= htmlspecialchars($p['gambar']); ?>" alt="<?= htmlspecialchars($p['nama_produk']); ?>">
                <?php else: ?>
                    <div class="product-image-placeholder">📦</div>
                <?php endif; ?>
            </div>
            
            <div class="product-info">
                <div class="product-name"><?= htmlspecialchars($p['nama_produk']); ?></div>
                <div class="product-category"><?= htmlspecialchars($p['nama_kategori'] ?? 'Tanpa Kategori'); ?></div>
                <div class="product-price">Rp <?= $harga_format; ?></div>
                
                <div class="product-stock">
                    Stok: <strong><?= $p['stok']; ?></strong>
                    <span class="stock-badge <?= $stok_class; ?>">
                        <?= $p['stok'] > 10 ? 'Ready Stock' : 'Limited'; ?>
                    </span>
                </div>
                
                <form method="POST" class="product-form">
                    <input type="hidden" name="id_produk" value="<?= $p['id_produk']; ?>">
                    
                    <div class="qty-input">
                        <label for="qty_<?= $p['id_produk']; ?>">Qty:</label>
                        <input 
                            type="number" 
                            id="qty_<?= $p['id_produk']; ?>" 
                            name="jumlah" 
                            value="1" 
                            min="1" 
                            max="<?= $p['stok']; ?>"
                            required
                        >
                    </div>
                    
                    <button type="submit" name="add_to_cart" class="add-cart-btn">
                        🛒 Tambah ke Keranjang
                    </button>
                </form>
            </div>
        </div>
        <?php 
            } 
        } else {
        ?>
        <div class="empty-state">
            <div class="icon">📦</div>
            <p>Maaf, semua produk sedang tidak tersedia</p>
        </div>
        <?php } ?>
    </div>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.3s';
        document.body.style.opacity = '1';
    }, 100);
});

// Auto-hide alerts
<?php if ($add_success || $add_error): ?>
setTimeout(() => {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        alert.style.transition = 'all 0.3s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    });
}, 3000);
<?php endif; ?>
</script>

</body>
</html>

