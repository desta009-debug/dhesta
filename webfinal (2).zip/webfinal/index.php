<?php
require_once 'config.php';

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'staff') {
        redirect('dashboard_staff.php');
    } else {
        redirect('dashboard_pembeli.php');
    }
}

// Redirect ke login jika belum login
redirect('login.php');
?>
