<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pembeli') {
    header("Location: login.php");
    exit;
}

$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Pembeli';

$total_harga = 0;
$keranjang_items = [];

// Ambil data keranjang
$result = mysqli_query($conn, "
    SELECT k.id_keranjang, k.jumlah, 
           p.id_produk, p.nama_produk, p.gambar, p.harga
    FROM keranjang k
    JOIN produk p ON k.id_produk = p.id_produk
    WHERE k.id_user = $id_user
");

while ($row = mysqli_fetch_assoc($result)) {
    $keranjang_items[] = $row;
    $total_harga += $row['jumlah'] * $row['harga'];
}

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'hapus') {
            $id_keranjang = mysqli_real_escape_string($conn, $_POST['id_keranjang']);
            mysqli_query($conn, "DELETE FROM keranjang WHERE id_keranjang = $id_keranjang");
            header("Location: keranjang.php");
            exit;
        }
        
        if ($action == 'update') {
            $id_keranjang = mysqli_real_escape_string($conn, $_POST['id_keranjang']);
            $jumlah = mysqli_real_escape_string($conn, $_POST['jumlah']);
            
            if ($jumlah > 0) {
                mysqli_query($conn, "UPDATE keranjang SET jumlah = $jumlah WHERE id_keranjang = $id_keranjang");
            }
            header("Location: keranjang.php");
            exit;
        }
        
        if ($action == 'checkout') {
            $metode_pembayaran = mysqli_real_escape_string($conn, $_POST['metode_pembayaran']);
            $alamat_pengiriman = mysqli_real_escape_string($conn, $_POST['alamat_pengiriman']);
            $nomor_telepon = mysqli_real_escape_string($conn, $_POST['nomor_telepon'] ?? '');
            $catatan = mysqli_real_escape_string($conn, $_POST['catatan'] ?? '');
            
            // Validasi metode pembayaran
            if (empty($metode_pembayaran)) {
                $_SESSION['checkout_error'] = "Pilih metode pembayaran!";
                header("Location: keranjang.php");
                exit;
            }

            // Validasi alamat pengiriman
            if (empty($alamat_pengiriman) || strlen(trim($alamat_pengiriman)) < 10) {
                $_SESSION['checkout_error'] = "Alamat pengiriman harus diisi minimal 10 karakter!";
                header("Location: keranjang.php");
                exit;
            }

            $valid_methods = ['transfer_bank', 'e_wallet', 'cicilan', 'cash'];
            if (!in_array($metode_pembayaran, $valid_methods)) {
                $_SESSION['checkout_error'] = "Metode pembayaran tidak valid!";
                header("Location: keranjang.php");
                exit;
            }

            $fresh_cart = mysqli_query($conn, "
                SELECT k.id_keranjang, k.jumlah, 
                       p.id_produk, p.nama_produk, p.harga
                FROM keranjang k
                JOIN produk p ON k.id_produk = p.id_produk
                WHERE k.id_user = $id_user
                ORDER BY k.id_keranjang ASC
            ");

            $fresh_items = [];
            $fresh_total = 0;
            
            while ($row = mysqli_fetch_assoc($fresh_cart)) {
                $id_produk = (int)$row['id_produk'];
                $jumlah = (int)$row['jumlah'];
                $harga = (int)$row['harga'];
                
                if ($id_produk <= 0 || $jumlah <= 0 || $harga <= 0) {
                    continue;
                }
                
                $fresh_items[] = [
                    'id_produk' => $id_produk,
                    'nama_produk' => $row['nama_produk'],
                    'jumlah' => $jumlah,
                    'harga' => $harga,
                    'subtotal' => $jumlah * $harga
                ];
                
                $fresh_total += ($jumlah * $harga);
            }

            if (empty($fresh_items)) {
                $_SESSION['checkout_error'] = "Keranjang Anda kosong!";
                header("Location: keranjang.php");
                exit;
            }

            $tanggal_order = date('Y-m-d H:i:s');
            $total_harga = (int)$fresh_total;
            
            // Simpan order dengan alamat pengiriman
            $insert_order = "
                INSERT INTO orders (id_user, total_harga, metode_pembayaran, alamat_pengiriman, nomor_telepon, catatan, status, tanggal_order) 
                VALUES ($id_user, $total_harga, '$metode_pembayaran', '$alamat_pengiriman', '$nomor_telepon', '$catatan', 'pending', '$tanggal_order')
            ";
            
            if (!mysqli_query($conn, $insert_order)) {
                $_SESSION['checkout_error'] = "Gagal membuat pesanan!";
                header("Location: keranjang.php");
                exit;
            }

            $id_order = mysqli_insert_id($conn);

            // Masukkan item order
            foreach ($fresh_items as $item) {
                $subtotal = (int)$item['subtotal'];
                mysqli_query($conn, "INSERT INTO order_items (id_order, id_produk, jumlah, harga_satuan, subtotal) 
                    VALUES ($id_order, {$item['id_produk']}, {$item['jumlah']}, {$item['harga']}, $subtotal)");
            }

            // Bersihkan keranjang
            mysqli_query($conn, "DELETE FROM keranjang WHERE id_user = $id_user");

            $_SESSION['checkout_success'] = "Pesanan berhasil dibuat! No. Order: #$id_order";
            $_SESSION['last_order_id'] = $id_order;
            
            header("Location: riwayat_pesanan.php");
            exit;
        }
    }
}

$checkout_success = $_SESSION['checkout_success'] ?? '';
$checkout_error = $_SESSION['checkout_error'] ?? '';
unset($_SESSION['checkout_success']);
unset($_SESSION['checkout_error']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Keranjang Belanja - Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== PAGE HEADER ========== */
.page-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.page-header h1 {
    font-size: 36px;
    margin-bottom: 8px;
    font-weight: 700;
}

.page-header p {
    font-size: 16px;
    opacity: 0.9;
}

/* ========== NOTIFICATIONS ========== */
.notification {
    padding: 15px 20px;
    margin-bottom: 25px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideIn 0.5s ease-out;
}

.notification.success {
    background: linear-gradient(135deg, var(--success), #66bb6a);
    color: white;
    box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
}

.notification.error {
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
    box-shadow: 0 4px 15px rgba(244, 67, 54, 0.3);
}

/* ========== CART SECTION ========== */
.cart-section {
    background: white;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
}

.cart-section h2 {
    font-size: 24px;
    color: var(--primary);
    margin-bottom: 25px;
    font-weight: 700;
}

.cart-item {
    display: grid;
    grid-template-columns: 100px 1fr 120px 150px 100px;
    gap: 20px;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid #e0e0e0;
}

.cart-item:last-child {
    border-bottom: none;
}

.item-image {
    width: 100px;
    height: 100px;
    background: #f5f5f5;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.item-image img {
    max-width: 100%;
    max-height: 100%;
    object-fit: cover;
}

.item-info h3 {
    font-size: 18px;
    color: var(--primary);
    margin-bottom: 8px;
}

.item-price {
    color: var(--accent);
    font-weight: 600;
    font-size: 16px;
}

.item-quantity form {
    display: flex;
    gap: 10px;
    align-items: center;
}

.item-quantity input {
    width: 70px;
    padding: 10px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    text-align: center;
    font-size: 16px;
}

.btn-update {
    padding: 8px 15px;
    background: var(--warning);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-update:hover {
    background: #f57c00;
}

.item-subtotal {
    font-size: 20px;
    font-weight: 700;
    color: var(--primary);
    text-align: right;
}

.item-actions {
    text-align: center;
}

.btn-delete {
    padding: 10px 20px;
    background: linear-gradient(135deg, var(--danger), #ef5350);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-delete:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(244, 67, 54, 0.4);
}

/* ========== CHECKOUT SECTION ========== */
.checkout-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.summary-box, .payment-box {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.summary-box h3, .payment-box h3 {
    font-size: 20px;
    color: var(--primary);
    margin-bottom: 20px;
    font-weight: 700;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid #e0e0e0;
}

.summary-total {
    display: flex;
    justify-content: space-between;
    padding: 20px 0;
    font-size: 24px;
    font-weight: 700;
    color: var(--accent);
}

.payment-option {
    margin-bottom: 15px;
}

.payment-option label {
    display: flex;
    align-items: center;
    padding: 15px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s;
}

.payment-option label:hover {
    border-color: var(--accent);
    background: rgba(67, 160, 71, 0.05);
}

.payment-option input[type="radio"]:checked + label {
    border-color: var(--accent);
    background: rgba(67, 160, 71, 0.1);
}

.payment-option input[type="radio"] {
    margin-right: 12px;
}

.payment-details {
    flex: 1;
}

.payment-details strong {
    display: block;
    font-size: 16px;
    margin-bottom: 4px;
}

.payment-details small {
    color: #666;
}

/* ========== FORM INPUT STYLES ========== */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    color: var(--primary);
    margin-bottom: 8px;
    font-size: 14px;
}

.form-group label .required {
    color: var(--danger);
    margin-left: 4px;
}

.form-group textarea,
.form-group input[type="text"],
.form-group input[type="tel"] {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    font-family: inherit;
    transition: all 0.3s;
}

.form-group textarea:focus,
.form-group input[type="text"]:focus,
.form-group input[type="tel"]:focus {
    outline: none;
    border-color: var(--accent);
    background: rgba(67, 160, 71, 0.05);
}

.form-group textarea {
    resize: vertical;
    min-height: 100px;
}

.form-group input[type="text"]::placeholder,
.form-group input[type="tel"]::placeholder,
.form-group textarea::placeholder {
    color: #999;
}

.form-hint {
    font-size: 12px;
    color: #666;
    margin-top: 5px;
}

.checkout-actions {
    display: flex;
    gap: 15px;
    margin-top: 25px;
}

.btn-primary, .btn-secondary {
    flex: 1;
    padding: 15px;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
    transition: all 0.3s;
}

.btn-primary {
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
}

.btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(67, 160, 71, 0.4);
}

.btn-secondary {
    background: #666;
    color: white;
}

.btn-secondary:hover {
    background: #555;
}

/* ========== EMPTY STATE ========== */
.empty-cart {
    text-align: center;
    padding: 80px 20px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.empty-cart-icon {
    font-size: 100px;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-cart h2 {
    font-size: 28px;
    color: var(--primary);
    margin-bottom: 10px;
}

.empty-cart p {
    color: #666;
    font-size: 16px;
    margin-bottom: 30px;
}

.empty-cart a {
    display: inline-block;
    padding: 15px 40px;
    background: linear-gradient(135deg, var(--accent), var(--success));
    color: white;
    text-decoration: none;
    border-radius: 12px;
    font-weight: 700;
    transition: all 0.3s;
}

.empty-cart a:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(67, 160, 71, 0.4);
}

/* ========== RESPONSIVE ========== */
@media (max-width: 968px) {
    .cart-item {
        grid-template-columns: 1fr;
        gap: 15px;
    }
    
    .checkout-section {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header h1 {
        font-size: 28px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👋</span>
            <span class="badge-text">Halo, <?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_pembeli.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="produk.php">
            <span class="icon">🛍️</span>
            <span>Belanja Produk</span>
        </a>
        <a href="keranjang.php" class="active">
            <span class="icon">🛒</span>
            <span>Keranjang</span>
        </a>
        <a href="riwayat_pesanan.php">
            <span class="icon">📋</span>
            <span>Riwayat Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h1>🛒 Keranjang Belanja</h1>
        <p>Review dan kelola produk dalam keranjang Anda</p>
    </div>

    <!-- NOTIFICATIONS -->
    <?php if ($checkout_success): ?>
        <div class="notification success">
            <span>✅</span>
            <span><?= htmlspecialchars($checkout_success); ?></span>
        </div>
    <?php endif; ?>

    <?php if ($checkout_error): ?>
        <div class="notification error">
            <span>⚠️</span>
            <span><?= htmlspecialchars($checkout_error); ?></span>
        </div>
    <?php endif; ?>

    <?php if (empty($keranjang_items)): ?>
        <div class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <h2>Keranjang Anda Kosong</h2>
            <p>Mulai belanja produk favorit Anda sekarang!</p>
            <a href="produk.php">🛍️ Jelajahi Produk</a>
        </div>
    <?php else: ?>
        <!-- CART ITEMS -->
        <div class="cart-section">
            <h2>📦 Daftar Produk (<?= count($keranjang_items); ?> item)</h2>
            <?php foreach ($keranjang_items as $item): ?>
                <div class="cart-item">
                    <div class="item-image">
                        <?php if ($item['gambar']): ?>
                            <img src="uploads/<?= $item['gambar']; ?>" alt="<?= htmlspecialchars($item['nama_produk']); ?>">
                        <?php else: ?>
                            <span style="font-size: 40px;">📦</span>
                        <?php endif; ?>
                    </div>
                    <div class="item-info">
                        <h3><?= htmlspecialchars($item['nama_produk']); ?></h3>
                        <div class="item-price">Rp <?= number_format($item['harga'], 0, ',', '.'); ?>/pcs</div>
                    </div>
                    <div class="item-quantity">
                        <form method="POST">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="id_keranjang" value="<?= $item['id_keranjang']; ?>">
                            <input type="number" name="jumlah" value="<?= $item['jumlah']; ?>" min="1" max="100">
                            <button type="submit" class="btn-update">Update</button>
                        </form>
                    </div>
                    <div class="item-subtotal">
                        Rp <?= number_format($item['jumlah'] * $item['harga'], 0, ',', '.'); ?>
                    </div>
                    <div class="item-actions">
                        <form method="POST">
                            <input type="hidden" name="action" value="hapus">
                            <input type="hidden" name="id_keranjang" value="<?= $item['id_keranjang']; ?>">
                            <button type="submit" class="btn-delete" onclick="return confirm('Yakin hapus produk ini?')">🗑️ Hapus</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- CHECKOUT SECTION -->
        <div class="checkout-section">
            <div class="summary-box">
                <h3>📊 Ringkasan Belanja</h3>
                <div class="summary-item">
                    <span>Total Item:</span>
                    <span><strong><?= count($keranjang_items); ?></strong> produk</span>
                </div>
                
                <div class="summary-item">
                    <span>Subtotal:</span>
                    <span>Rp <?= number_format($total_harga, 0, ',', '.'); ?></span>
                </div>
                <div class="summary-total">
                    <span>Total:</span>
                    <span>Rp <?= number_format($total_harga, 0, ',', '.'); ?></span>
                </div>
            </div>

            <div class="payment-box">
                <h3>💳 Informasi Pengiriman & Pembayaran</h3>
                <form method="POST" id="checkoutForm">
                    <input type="hidden" name="action" value="checkout">
                    
                    <!-- ALAMAT PENGIRIMAN -->
                    <div class="form-group">
                        <label for="alamat_pengiriman">
                            📍 Alamat Pengiriman <span class="required">*</span>
                        </label>
                        <textarea 
                            name="alamat_pengiriman" 
                            id="alamat_pengiriman" 
                            required 
                            placeholder="Contoh: Jl. Merdeka No. 123, RT 01/RW 05, Kelurahan Suka Maju, Kecamatan Sejahtera, Kota Jakarta Selatan, DKI Jakarta 12345"
                        ></textarea>
                        <div class="form-hint">Masukkan alamat lengkap termasuk RT/RW, kelurahan, kecamatan, kota, dan kode pos (min. 10 karakter)</div>
                    </div>

                    <!-- NOMOR TELEPON -->
                    <div class="form-group">
                        <label for="nomor_telepon">
                            📱 Nomor Telepon/WhatsApp
                        </label>
                        <input 
                            type="tel" 
                            name="nomor_telepon" 
                            id="nomor_telepon" 
                            placeholder="Contoh: 081234567890"
                            pattern="[0-9]{10,13}"
                        >
                        <div class="form-hint">Nomor yang dapat dihubungi untuk konfirmasi pesanan (opsional)</div>
                    </div>

                    <!-- CATATAN -->
                    <div class="form-group">
                        <label for="catatan">
                            📝 Catatan Pesanan
                        </label>
                        <textarea 
                            name="catatan" 
                            id="catatan" 
                            placeholder="Contoh: Tolong kirim pagi hari, paket jangan dibanting, dll."
                            style="min-height: 80px;"
                        ></textarea>
                        <div class="form-hint">Tambahkan catatan khusus untuk pesanan Anda (opsional)</div>
                    </div>

                    <hr style="margin: 25px 0; border: none; border-top: 1px solid #e0e0e0;">

                    <!-- METODE PEMBAYARAN -->
                    <h3 style="font-size: 18px; margin-bottom: 15px; color: var(--primary);">💳 Pilih Metode Pembayaran <span class="required">*</span></h3>
                    
                    <div class="payment-option">
                        <input type="radio" name="metode_pembayaran" value="transfer_bank" id="bank" required>
                        <label for="bank">
                            <div class="payment-details">
                                <strong>🏦 Transfer Bank</strong>
                                <small>BCA, Mandiri, BNI, CIMB</small>
                            </div>
                        </label>
                    </div>

                    <div class="payment-option">
                        <input type="radio" name="metode_pembayaran" value="e_wallet" id="ewallet" required>
                        <label for="ewallet">
                            <div class="payment-details">
                                <strong>📱 E-Wallet</strong>
                                <small>GoPay, OVO, Dana, ShopeePay</small>
                            </div>
                        </label>
                    </div>

                    <div class="payment-option">
                        <input type="radio" name="metode_pembayaran" value="cicilan" id="cicilan" required>
                        <label for="cicilan">
                            <div class="payment-details">
                                <strong>💳 Cicilan</strong>
                                <small>Cicilan 0% hingga 12 bulan</small>
                            </div>
                        </label>
                    </div>

                    <div class="payment-option">
                        <input type="radio" name="metode_pembayaran" value="cash" id="cash" required>
                        <label for="cash">
                            <div class="payment-details">
                                <strong>💰 Bayar di Tempat</strong>
                                <small>Bayar saat barang diterima</small>
                            </div>
                        </label>
                    </div>

                    <div class="checkout-actions">
                        <a href="produk.php" class="btn-secondary">🛍️ Lanjut Belanja</a>
                        <button type="submit" class="btn-primary" onclick="return validateCheckout()">
                            ✅ Checkout Sekarang
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Validate checkout form
function validateCheckout() {
    const alamat = document.getElementById('alamat_pengiriman').value.trim();
    const metode = document.querySelector('input[name="metode_pembayaran"]:checked');
    
    if (alamat.length < 10) {
        alert('⚠️ Alamat pengiriman harus diisi minimal 10 karakter!');
        document.getElementById('alamat_pengiriman').focus();
        return false;
    }
    
    if (!metode) {
        alert('⚠️ Pilih metode pembayaran terlebih dahulu!');
        return false;
    }
    
    return confirm('✅ Lanjutkan checkout dengan total Rp <?= number_format($total_harga, 0, ',', '.'); ?>?');
}

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.3s';
        document.body.style.opacity = '1';
    }, 100);
});

// Auto-hide notifications
const notifications = document.querySelectorAll('.notification');
notifications.forEach(notif => {
    setTimeout(() => {
        notif.style.transition = 'all 0.5s';
        notif.style.opacity = '0';
        notif.style.transform = 'translateY(-20px)';
        setTimeout(() => notif.remove(), 500);
    }, 5000);
});

// Payment option selection visual feedback
const paymentOptions = document.querySelectorAll('.payment-option input[type="radio"]');
paymentOptions.forEach(option => {
    option.addEventListener('change', function() {
        document.querySelectorAll('.payment-option label').forEach(label => {
            label.style.borderColor = '#e0e0e0';
            label.style.background = 'white';
        });
        if (this.checked) {
            this.parentElement.querySelector('label').style.borderColor = 'var(--accent)';
            this.parentElement.querySelector('label').style.background = 'rgba(67, 160, 71, 0.1)';
        }
    });
});

// Character counter for address (optional enhancement)
const alamatField = document.getElementById('alamat_pengiriman');
alamatField.addEventListener('input', function() {
    const length = this.value.trim().length;
    const hint = this.nextElementSibling;
    if (length > 0 && length < 10) {
        hint.style.color = 'var(--danger)';
        hint.textContent = `⚠️ Masih kurang ${10 - length} karakter lagi`;
    } else if (length >= 10) {
        hint.style.color = 'var(--success)';
        hint.textContent = '✅ Alamat sudah valid';
    } else {
        hint.style.color = '#666';
        hint.textContent = 'Masukkan alamat lengkap termasuk RT/RW, kelurahan, kecamatan, kota, dan kode pos (min. 10 karakter)';
    }
});
</script>

</body>
</html>