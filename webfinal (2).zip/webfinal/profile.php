<?php
session_start();
require 'config.php';

// Proteksi login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$id_user = $_SESSION['user_id'];
$success = '';
$error = '';

// Update foto profil
if (isset($_POST['update_photo'])) {
    $upload_dir = 'uploads/profile/';
    
    // Create directory if not exists
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    if (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        $file_type = $_FILES['foto_profil']['type'];
        $file_size = $_FILES['foto_profil']['size'];
        
        // Validate file type
        if (!in_array($file_type, $allowed_types)) {
            $error = 'Format file tidak didukung! Gunakan JPG, PNG, atau GIF.';
        }
        // Validate file size (max 2MB)
        elseif ($file_size > 2 * 1024 * 1024) {
            $error = 'Ukuran file terlalu besar! Maksimal 2MB.';
        }
        else {
            $file_extension = pathinfo($_FILES['foto_profil']['name'], PATHINFO_EXTENSION);
            $new_filename = 'profile_' . $id_user . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            // Delete old photo if exists
            $old_photo_query = mysqli_query($conn, "SELECT foto_profil FROM users WHERE id_user=$id_user");
            if ($old_photo_query && mysqli_num_rows($old_photo_query) > 0) {
                $old_photo_data = mysqli_fetch_assoc($old_photo_query);
                if (!empty($old_photo_data['foto_profil']) && file_exists($old_photo_data['foto_profil'])) {
                    unlink($old_photo_data['foto_profil']);
                }
            }
            
            // Upload new photo
            if (move_uploaded_file($_FILES['foto_profil']['tmp_name'], $upload_path)) {
                $update_photo_query = "UPDATE users SET foto_profil='$upload_path' WHERE id_user=$id_user";
                if (mysqli_query($conn, $update_photo_query)) {
                    $success = 'Foto profil berhasil diperbarui!';
                } else {
                    $error = 'Gagal menyimpan foto ke database: ' . mysqli_error($conn);
                    unlink($upload_path); // Delete uploaded file if database update fails
                }
            } else {
                $error = 'Gagal mengupload foto!';
            }
        }
    } else {
        $error = 'Silakan pilih file foto terlebih dahulu!';
    }
}

// Delete foto profil
if (isset($_POST['delete_photo'])) {
    $photo_query = mysqli_query($conn, "SELECT foto_profil FROM users WHERE id_user=$id_user");
    if ($photo_query && mysqli_num_rows($photo_query) > 0) {
        $photo_data = mysqli_fetch_assoc($photo_query);
        if (!empty($photo_data['foto_profil']) && file_exists($photo_data['foto_profil'])) {
            unlink($photo_data['foto_profil']);
        }
        
        $delete_query = "UPDATE users SET foto_profil=NULL WHERE id_user=$id_user";
        if (mysqli_query($conn, $delete_query)) {
            $success = 'Foto profil berhasil dihapus!';
        } else {
            $error = 'Gagal menghapus foto profil: ' . mysqli_error($conn);
        }
    }
}

// Update profil
if (isset($_POST['update'])) {
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if email already exists (for other users)
    $email_check = mysqli_query($conn, "SELECT id_user FROM users WHERE email='$email' AND id_user != $id_user");
    if (mysqli_num_rows($email_check) > 0) {
        $error = 'Email sudah digunakan oleh user lain!';
    } else {
        $update_query = "UPDATE users SET nama='$nama', email='$email' WHERE id_user=$id_user";
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['nama'] = $nama;
            $success = 'Profil berhasil diperbarui!';
        } else {
            $error = 'Gagal memperbarui profil: ' . mysqli_error($conn);
        }
    }
}

// Update password
if (isset($_POST['update_password'])) {
    $password_lama = mysqli_real_escape_string($conn, trim($_POST['password_lama']));
    $password_baru = mysqli_real_escape_string($conn, trim($_POST['password_baru']));
    $password_konfirmasi = mysqli_real_escape_string($conn, trim($_POST['password_konfirmasi']));
    
    // Get current password
    $pass_query = mysqli_query($conn, "SELECT password FROM users WHERE id_user=$id_user");
    
    if (!$pass_query) {
        $error = 'Error database: ' . mysqli_error($conn);
    } else {
        $pass_data = mysqli_fetch_assoc($pass_query);
        $current_password = $pass_data['password'];
        
        // Validate old password
        if ($password_lama !== $current_password) {
            $error = 'Password lama tidak sesuai!';
        }
        // Validate new password confirmation
        elseif ($password_baru !== $password_konfirmasi) {
            $error = 'Konfirmasi password baru tidak cocok!';
        }
        // Validate password length
        elseif (strlen($password_baru) < 3) {
            $error = 'Password baru minimal 3 karakter!';
        }
        // Validate new password is different from old
        elseif ($password_lama === $password_baru) {
            $error = 'Password baru harus berbeda dari password lama!';
        }
        // All validations passed - update password
        else {
            $update_pass_query = "UPDATE users SET password='$password_baru' WHERE id_user=$id_user";
            
            if (mysqli_query($conn, $update_pass_query)) {
                $success = 'Password berhasil diperbarui! Silakan gunakan password baru untuk login berikutnya.';
            } else {
                $error = 'Gagal memperbarui password: ' . mysqli_error($conn);
            }
        }
    }
}

// Ambil data user
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE id_user=$id_user");
if (!$user_query || mysqli_num_rows($user_query) == 0) {
    die("Error: User tidak ditemukan!");
}

$user = mysqli_fetch_assoc($user_query);
$nama_user = $_SESSION['nama'] ?? $user['nama'];
$role = $user['role'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil - Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.sidebar.small .logo-image {
    width: 50px;
    height: 50px;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
    position: relative;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== HEADER ========== */
.header {
    margin-bottom: 35px;
}

.header h2 {
    color: var(--primary);
    font-size: 32px;
    font-weight: 700;
}

/* ========== PROFILE CARD ========== */
.profile-container {
    max-width: 900px;
    margin: 0 auto;
}

.card {
    background: white;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    margin-bottom: 30px;
}

.profile-header {
    text-align: center;
    margin-bottom: 35px;
    padding-bottom: 25px;
    border-bottom: 2px solid #f0f0f0;
}

.avatar {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, var(--accent) 0%, var(--success) 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 48px;
    margin: 0 auto 20px;
    box-shadow: 0 8px 20px rgba(67,160,71,0.3);
    overflow: hidden;
    position: relative;
}

.avatar-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.avatar-placeholder {
    font-size: 48px;
}

.profile-header h2 {
    font-size: 28px;
    color: var(--primary);
    margin-bottom: 10px;
}

.role-badge {
    display: inline-block;
    padding: 8px 20px;
    background: linear-gradient(135deg, var(--info) 0%, #42a5f5 100%);
    color: white;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* ========== PHOTO UPLOAD SECTION ========== */
.photo-upload-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    align-items: start;
}

.current-photo {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 12px;
    min-height: 250px;
}

.preview-image {
    width: 200px;
    height: 200px;
    object-fit: cover;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.no-photo {
    text-align: center;
    color: #999;
}

.no-photo p {
    margin-top: 10px;
    font-size: 14px;
}

.upload-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.file-info {
    margin-top: 8px;
    font-size: 12px;
    color: #666;
}

.photo-preview {
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    text-align: center;
}

.photo-preview img {
    max-width: 100%;
    max-height: 200px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.button-group {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.button-group button {
    flex: 1;
    min-width: 150px;
}

/* ========== SECTION HEADER ========== */
.section-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
}

.section-header h3 {
    font-size: 20px;
    color: var(--primary);
}

/* ========== FORM ========== */
.form-group {
    margin-bottom: 25px;
}

label {
    display: block;
    font-weight: 600;
    font-size: 14px;
    color: var(--primary);
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

input {
    width: 100%;
    padding: 14px 16px;
    border-radius: 10px;
    border: 2px solid #e0e0e0;
    font-size: 15px;
    transition: all 0.3s;
    background: #fafafa;
}

input:focus {
    outline: none;
    border-color: var(--accent);
    background: white;
    box-shadow: 0 4px 12px rgba(67,160,71,0.1);
}

input:disabled {
    background: #f5f5f5;
    cursor: not-allowed;
}

input[type="password"] {
    font-family: 'Courier New', monospace;
    letter-spacing: 2px;
}

/* ========== BUTTON ========== */
.btn-submit {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, var(--accent) 0%, var(--success) 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 10px;
    box-shadow: 0 4px 15px rgba(67,160,71,0.3);
}

.btn-submit:hover {
    background: linear-gradient(135deg, #2e7d32 0%, #388e3c 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(67,160,71,0.4);
}

.btn-submit:active {
    transform: translateY(0);
}

.btn-danger {
    background: linear-gradient(135deg, var(--danger) 0%, #ef5350 100%);
    box-shadow: 0 4px 15px rgba(244,67,54,0.3);
}

.btn-danger:hover {
    background: linear-gradient(135deg, #c62828 0%, #d32f2f 100%);
    box-shadow: 0 6px 20px rgba(244,67,54,0.4);
}

/* ========== ALERT ========== */
.alert {
    padding: 16px 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.alert-success {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
    border-left: 4px solid var(--success);
}

.alert-error {
    background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%);
    color: #b71c1c;
    border-left: 4px solid var(--danger);
}

.alert-icon {
    font-size: 24px;
}

/* ========== INFO SECTION ========== */
.info-section {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin-top: 30px;
    border-left: 4px solid var(--info);
}

.info-section h3 {
    color: var(--primary);
    font-size: 16px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-section p {
    color: #666;
    font-size: 14px;
    line-height: 1.6;
}

.info-section ul {
    margin-top: 10px;
    margin-left: 20px;
    color: #666;
    font-size: 14px;
    line-height: 1.8;
}

/* ========== PASSWORD STRENGTH INDICATOR ========== */
.password-strength {
    margin-top: 8px;
    height: 4px;
    background: #e0e0e0;
    border-radius: 2px;
    overflow: hidden;
}

.password-strength-bar {
    height: 100%;
    width: 0%;
    transition: all 0.3s;
}

.strength-weak { 
    width: 33%; 
    background: var(--danger); 
}

.strength-medium { 
    width: 66%; 
    background: var(--warning); 
}

.strength-strong { 
    width: 100%; 
    background: var(--success); 
}

.password-hint {
    margin-top: 8px;
    font-size: 12px;
    color: #666;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .sidebar .badge-content {
        justify-content: center;
        border-left: none;
        background: transparent;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .card {
        padding: 25px 20px;
    }
    
    .profile-header h2 {
        font-size: 22px;
    }
    
    .avatar {
        width: 80px;
        height: 80px;
        font-size: 40px;
    }
    
    .photo-upload-section {
        grid-template-columns: 1fr;
    }
    
    .button-group {
        flex-direction: column;
    }
    
    .button-group button {
        width: 100%;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <!-- USER INFO -->
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👋</span>
            <span class="badge-text">Halo, <?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <?php if($role == 'staff'): ?>
            <a href="dashboard_staff.php">
                <span class="icon">🏠</span>
                <span>Dashboard</span>
            </a>
            <a href="kelola_pesanan.php">
                <span class="icon">📋</span>
                <span>Kelola Pesanan</span>
            </a>
            <a href="data_produk.php">
                <span class="icon">📦</span>
                <span>Data Produk</span>
            </a>
            <a href="kategori.php">
                <span class="icon">🏷️</span>
                <span>Kategori</span>
            </a>
            <a href="barang_keluar.php">
                <span class="icon">📤</span>
                <span>Barang Keluar</span>
            </a>
        <?php else: ?>
            <a href="dashboard_pembeli.php">
                <span class="icon">🏠</span>
                <span>Dashboard</span>
            </a>
            <a href="keranjang.php">
                <span class="icon">🛒</span>
                <span>Keranjang</span>
            </a>
            <a href="riwayat_pesanan.php">
                <span class="icon">📋</span>
                <span>Riwayat Pesanan</span>
            </a>
        <?php endif; ?>
        <a href="profile.php" class="active">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <div class="header">
        <h2>👤 Profil Saya</h2>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <span class="alert-icon">✅</span>
            <span><?= htmlspecialchars($success); ?></span>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-error">
            <span class="alert-icon">❌</span>
            <span><?= htmlspecialchars($error); ?></span>
        </div>
    <?php endif; ?>

    <div class="profile-container">
        
        <!-- CARD FOTO PROFIL -->
        <div class="card">
            <div class="section-header">
                <span style="font-size: 24px;">📷</span>
                <h3>Foto Profil</h3>
            </div>

            <div class="photo-upload-section">
                <div class="current-photo">
                    <?php if (!empty($user['foto_profil']) && file_exists($user['foto_profil'])): ?>
                        <img src="<?= htmlspecialchars($user['foto_profil']); ?>" alt="Foto Profil" class="preview-image">
                    <?php else: ?>
                        <div class="no-photo">
                            <span style="font-size: 64px;">👤</span>
                            <p>Belum ada foto profil</p>
                        </div>
                    <?php endif; ?>
                </div>

                <form method="POST" enctype="multipart/form-data" class="upload-form">
                    <div class="form-group">
                        <label>📁 Pilih Foto Baru</label>
                        <input 
                            type="file" 
                            name="foto_profil" 
                            id="foto_profil"
                            accept="image/jpeg,image/jpg,image/png,image/gif"
                            onchange="previewPhoto(this)"
                        >
                        <div class="file-info">
                            Format: JPG, PNG, GIF | Maksimal: 2MB
                        </div>
                    </div>

                    <div class="photo-preview" id="photoPreview" style="display: none;">
                        <img id="previewImg" src="" alt="Preview">
                    </div>

                    <div class="button-group">
                        <button type="submit" name="update_photo" class="btn-submit">
                            📷 Upload Foto
                        </button>
                        <?php if (!empty($user['foto_profil'])): ?>
                            <button type="submit" name="delete_photo" class="btn-submit btn-secondary" onclick="return confirm('Yakin ingin menghapus foto profil?')">
                                🗑️ Hapus Foto
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- CARD INFORMASI PROFIL -->
        <div class="card">
            
            <div class="profile-header">
                <div class="avatar">
                    <?php if (!empty($user['foto_profil']) && file_exists($user['foto_profil'])): ?>
                        <img src="<?= htmlspecialchars($user['foto_profil']); ?>" alt="Foto Profil" class="avatar-image">
                    <?php else: ?>
                        <span class="avatar-placeholder">👤</span>
                    <?php endif; ?>
                </div>
                <h2><?= htmlspecialchars($user['nama']); ?></h2>
                <span class="role-badge">
                    <?= $role == 'staff' ? '🛠️ Staff' : '🛒 Pembeli'; ?>
                </span>
            </div>

            <div class="section-header">
                <span style="font-size: 24px;">📝</span>
                <h3>Informasi Akun</h3>
            </div>

            <form method="POST">
                <div class="form-group">
                    <label>📝 Nama Lengkap</label>
                    <input 
                        type="text" 
                        name="nama" 
                        value="<?= htmlspecialchars($user['nama']); ?>" 
                        required
                        placeholder="Masukkan nama lengkap"
                    >
                </div>

                <div class="form-group">
                    <label>📧 Email</label>
                    <input 
                        type="email" 
                        name="email" 
                        value="<?= htmlspecialchars($user['email']); ?>" 
                        required
                        placeholder="email@example.com"
                    >
                </div>

                <button type="submit" name="update" class="btn-submit">
                    💾 Update Profil
                </button>
            </form>
        </div>

        <!-- CARD UBAH PASSWORD -->
        <div class="card">
            <div class="section-header">
                <span style="font-size: 24px;">🔐</span>
                <h3>Ubah Password</h3>
            </div>

            <form method="POST" id="passwordForm">
                <div class="form-group">
                    <label>🔒 Password Lama</label>
                    <input 
                        type="password" 
                        name="password_lama" 
                        id="password_lama"
                        placeholder="Masukkan password lama"
                        required
                        autocomplete="current-password"
                    >
                </div>

                <div class="form-group">
                    <label>🔑 Password Baru</label>
                    <input 
                        type="password" 
                        name="password_baru" 
                        id="password_baru"
                        placeholder="Masukkan password baru (min. 3 karakter)"
                        required
                        autocomplete="new-password"
                        oninput="checkPasswordStrength()"
                    >
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strengthBar"></div>
                    </div>
                    <div class="password-hint" id="strengthText"></div>
                </div>

                <div class="form-group">
                    <label>✓ Konfirmasi Password Baru</label>
                    <input 
                        type="password" 
                        name="password_konfirmasi" 
                        id="password_konfirmasi"
                        placeholder="Ulangi password baru"
                        required
                        autocomplete="new-password"
                        oninput="checkPasswordMatch()"
                    >
                    <div class="password-hint" id="matchText"></div>
                </div>

                <button type="submit" name="update_password" class="btn-submit btn-danger">
                    🔐 Ubah Password
                </button>
            </form>

            <div class="info-section">
                <h3>ℹ️ Tips Keamanan Password</h3>
                <ul>
                    <li>Gunakan kombinasi huruf besar, kecil, angka, dan simbol</li>
                    <li>Minimal 8 karakter untuk keamanan optimal</li>
                    <li>Jangan gunakan informasi pribadi yang mudah ditebak</li>
                    <li>Ubah password secara berkala (minimal 3 bulan sekali)</li>
                    <li>Jangan gunakan password yang sama di berbagai platform</li>
                </ul>
            </div>
        </div>

    </div>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Preview photo before upload
function previewPhoto(input) {
    const preview = document.getElementById('photoPreview');
    const previewImg = document.getElementById('previewImg');
    
    if (input.files && input.files[0]) {
        const file = input.files[0];
        
        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        if (!allowedTypes.includes(file.type)) {
            alert('⚠️ Format file tidak didukung! Gunakan JPG, PNG, atau GIF.');
            input.value = '';
            preview.style.display = 'none';
            return;
        }
        
        // Validate file size (2MB)
        if (file.size > 2 * 1024 * 1024) {
            alert('⚠️ Ukuran file terlalu besar! Maksimal 2MB.');
            input.value = '';
            preview.style.display = 'none';
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
}

// Check password strength
function checkPasswordStrength() {
    const password = document.getElementById('password_baru').value;
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    
    let strength = 0;
    
    if (password.length >= 3) strength++;
    if (password.length >= 6) strength++;
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;
    
    strengthBar.className = 'password-strength-bar';
    
    if (strength <= 2) {
        strengthBar.classList.add('strength-weak');
        strengthText.textContent = '⚠️ Password lemah';
        strengthText.style.color = '#f44336';
    } else if (strength <= 4) {
        strengthBar.classList.add('strength-medium');
        strengthText.textContent = '⚡ Password sedang';
        strengthText.style.color = '#ff9800';
    } else {
        strengthBar.classList.add('strength-strong');
        strengthText.textContent = '✓ Password kuat';
        strengthText.style.color = '#4caf50';
    }
}

// Check password match
function checkPasswordMatch() {
    const password = document.getElementById('password_baru').value;
    const confirm = document.getElementById('password_konfirmasi').value;
    const matchText = document.getElementById('matchText');
    
    if (confirm === '') {
        matchText.textContent = '';
        return;
    }
    
    if (password === confirm) {
        matchText.textContent = '✓ Password cocok';
        matchText.style.color = '#4caf50';
    } else {
        matchText.textContent = '✗ Password tidak cocok';
        matchText.style.color = '#f44336';
    }
}

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.3s';
        document.body.style.opacity = '1';
    }, 100);
});

// Auto-hide success/error message after 5 seconds
<?php if ($success || $error): ?>
setTimeout(() => {
    const alert = document.querySelector('.alert');
    if (alert) {
        alert.style.transition = 'all 0.3s';
        alert.style.opacity = '0';
        alert.style.transform = 'translateY(-10px)';
        setTimeout(() => alert.remove(), 300);
    }
}, 5000);
<?php endif; ?>

// Validate password form before submit
document.getElementById('passwordForm')?.addEventListener('submit', function(e) {
    const passwordBaru = document.getElementById('password_baru').value;
    const passwordKonfirmasi = document.getElementById('password_konfirmasi').value;
    
    if (passwordBaru !== passwordKonfirmasi) {
        e.preventDefault();
        alert('⚠️ Password baru dan konfirmasi password tidak cocok!');
        return false;
    }
    
    if (passwordBaru.length < 3) {
        e.preventDefault();
        alert('⚠️ Password baru minimal 3 karakter!');
        return false;
    }
    
    return confirm('🔐 Yakin ingin mengubah password?');
});

// Clear form after successful password update
<?php if ($success && strpos($success, 'Password') !== false): ?>
setTimeout(() => {
    document.getElementById('password_lama').value = '';
    document.getElementById('password_baru').value = '';
    document.getElementById('password_konfirmasi').value = '';
    document.getElementById('strengthBar').className = 'password-strength-bar';
    document.getElementById('strengthText').textContent = '';
    document.getElementById('matchText').textContent = '';
}, 100);
<?php endif; ?>
</script>

</body>
</html>