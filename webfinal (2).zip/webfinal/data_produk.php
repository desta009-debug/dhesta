<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Admin Staff';

// Handle Delete
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    
    // Hapus gambar jika ada
    $get_gambar = mysqli_query($conn, "SELECT gambar FROM produk WHERE id_produk = $id");
    $data_gambar = mysqli_fetch_assoc($get_gambar);
    if ($data_gambar && !empty($data_gambar['gambar'])) {
        $file_path = 'uploads/' . $data_gambar['gambar'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }
    
    mysqli_query($conn, "DELETE FROM produk WHERE id_produk = $id");
    header("Location: data_produk.php?success=delete");
    exit;
}

// Get all products with kategori and supplier info
$query = "
    SELECT 
        p.*,
        k.nama_kategori,
        s.nama_supplier,
        s.asal
    FROM produk p
    LEFT JOIN kategori k ON p.id_kategori = k.id_kategori
    LEFT JOIN suppliers s ON p.id_supplier = s.id_supplier
    ORDER BY p.id_produk DESC
";

$products = mysqli_query($conn, $query);

// Get success message if any
$success_message = '';
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'delete') {
        $success_message = 'Produk berhasil dihapus!';
    } elseif ($_GET['success'] == 'add') {
        $success_message = 'Produk berhasil ditambahkan!';
    } elseif ($_GET['success'] == 'edit') {
        $success_message = 'Produk berhasil diupdate!';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data Produk - Reborn Garage</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.sidebar.small .logo-image {
    width: 50px;
    height: 50px;
}

.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s;
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== HEADER ========== */
.page-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.page-header h1 {
    font-size: 36px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
}

.btn-add {
    background: linear-gradient(135deg, var(--accent) 0%, var(--success) 100%);
    color: white;
    padding: 14px 28px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s;
    box-shadow: 0 4px 15px rgba(67,160,71,0.3);
}

.btn-add:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(67,160,71,0.4);
}

/* ========== ALERT ========== */
.alert {
    padding: 16px 20px;
    border-radius: 12px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideDown 0.3s ease;
}

.alert-success {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
    border-left: 4px solid var(--success);
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ========== TABLE ========== */
.table-container {
    background: white;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    overflow: hidden;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background: var(--primary);
    color: white;
}

th {
    padding: 18px 16px;
    text-align: left;
    font-weight: 700;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

td {
    padding: 16px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 14px;
}

tbody tr {
    transition: all 0.2s;
}

tbody tr:hover {
    background: #f8f9fa;
    transform: scale(1.01);
}

/* ========== PRODUCT IMAGE ========== */
.product-image {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 10px;
    border: 2px solid #e0e0e0;
    transition: all 0.3s;
}

.product-image:hover {
    transform: scale(2);
    border-color: var(--accent);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    z-index: 100;
    cursor: pointer;
}

.no-image {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #e0e0e0 0%, #f5f5f5 100%);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: #999;
}

/* ========== STATUS BADGES ========== */
.status-badge {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

.status-ready {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
}

.status-low {
    background: linear-gradient(135deg, #fff3cd 0%, #ffe69c 100%);
    color: #856404;
}

.status-out {
    background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%);
    color: #b71c1c;
}

/* ========== ACTION BUTTONS ========== */
.action-buttons {
    display: flex;
    gap: 8px;
}

.btn {
    padding: 8px 16px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: none;
    cursor: pointer;
}

.btn-edit {
    background: linear-gradient(135deg, #1e88e5 0%, #42a5f5 100%);
    color: white;
}

.btn-edit:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(30,136,229,0.3);
}

.btn-delete {
    background: linear-gradient(135deg, #f44336 0%, #ef5350 100%);
    color: white;
}

.btn-delete:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(244,67,54,0.3);
}

/* ========== PRICE STYLING ========== */
.price {
    font-weight: 700;
    color: var(--accent);
    font-size: 15px;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .page-header h1 {
        font-size: 28px;
    }
    
    .table-container {
        overflow-x: auto;
    }
    
    table {
        min-width: 1000px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-state .icon {
    font-size: 64px;
    margin-bottom: 20px;
}

.empty-state h3 {
    font-size: 24px;
    margin-bottom: 10px;
    color: #666;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👤</span>
            <span class="badge-text"><?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_staff.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="data_produk.php" class="active">
            <span class="icon">📦</span>
            <span>Kelola Produk</span>
        </a>
        <a href="kategori.php">
            <span class="icon">🏷️</span>
            <span>Kategori</span>
        </a>
        <a href="supplier.php">
            <span class="icon">🏭</span>
            <span>Supplier</span>
        </a>
        <a href="barang_masuk.php">
            <span class="icon">📥</span>
            <span>Barang Masuk</span>
        </a>
        <a href="barang_keluar.php">
            <span class="icon">📤</span>
            <span>Barang Keluar</span>
        </a>
        <a href="kelola_pesanan.php">
            <span class="icon">📋</span>
            <span>Kelola Pesanan</span>
        </a>
        <a href="profile.php">
            <span class="icon">👤</span>
            <span>Profil</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<!-- CONTENT -->
<div class="content" id="content">

    <div class="page-header">
        <h1>
            <span>📦</span>
            Data Produk
        </h1>
        <a href="tambah_produk.php" class="btn-add">
            <span>➕</span>
            Tambah Produk
        </a>
    </div>

    <?php if ($success_message): ?>
        <div class="alert alert-success">
            <span>✅</span>
            <span><?= $success_message; ?></span>
        </div>
    <?php endif; ?>

    <div class="table-container">
        <?php if (mysqli_num_rows($products) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>GAMBAR</th>
                        <th>NAMA PRODUK</th>
                        <th>KATEGORI</th>
                        <th>SUPPLIER</th>
                        <th>ASAL</th>
                        <th>HARGA</th>
                        <th>STOK</th>
                        <th>STATUS</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($products)): 
                        // Determine status
                        $stok = (int)$row['stok'];
                        if ($stok == 0) {
                            $status = '<span class="status-badge status-out">HABIS</span>';
                        } elseif ($stok <= 10) {
                            $status = '<span class="status-badge status-low">LOW STOCK</span>';
                        } else {
                            $status = '<span class="status-badge status-ready">READY</span>';
                        }
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td>
                                <?php if (!empty($row['gambar']) && file_exists('uploads/' . $row['gambar'])): ?>
                                    <img 
                                        src="uploads/<?= htmlspecialchars($row['gambar']); ?>" 
                                        alt="<?= htmlspecialchars($row['nama_produk']); ?>"
                                        class="product-image"
                                        title="Klik untuk perbesar"
                                    >
                                <?php else: ?>
                                    <div class="no-image" title="Tidak ada gambar">📷</div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= htmlspecialchars($row['nama_produk']); ?></strong></td>
                            <td><?= $row['nama_kategori'] ? htmlspecialchars($row['nama_kategori']) : '-'; ?></td>
                            <td><?= $row['nama_supplier'] ? htmlspecialchars($row['nama_supplier']) : '-'; ?></td>
                            <td><?= $row['asal'] ? htmlspecialchars($row['asal']) : '-'; ?></td>
                            <td><span class="price">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></span></td>
                            <td><?= $stok; ?></td>
                            <td><?= $status; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="edit_produk.php?id=<?= $row['id_produk']; ?>" class="btn btn-edit">
                                        🖊️ Edit
                                    </a>
                                    <a 
                                        href="data_produk.php?hapus=<?= $row['id_produk']; ?>" 
                                        class="btn btn-delete"
                                        onclick="return confirm('Yakin ingin menghapus produk <?= htmlspecialchars($row['nama_produk']); ?>?')"
                                    >
                                        🗑️ Hapus
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state">
                <div class="icon">📦</div>
                <h3>Belum Ada Produk</h3>
                <p>Mulai tambahkan produk untuk mengelola inventory Anda</p>
            </div>
        <?php endif; ?>
    </div>

</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

// Auto-hide success alert
<?php if ($success_message): ?>
setTimeout(() => {
    const alert = document.querySelector('.alert-success');
    if (alert) {
        alert.style.transition = 'all 0.3s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }
}, 4000);
<?php endif; ?>

// Smooth page load animation
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s';
        document.body.style.opacity = '1';
    }, 100);
});
</script>

</body>
</html>