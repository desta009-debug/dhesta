<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}

// Get user info
$id_user = $_SESSION['user_id'];
$user_query = mysqli_query($conn, "SELECT nama FROM users WHERE id_user = $id_user");
$user_data = mysqli_fetch_assoc($user_query);
$nama_user = $user_data['nama'] ?? 'Staff';

$success = "";
$error = "";

// Get ID dari URL
if (!isset($_GET['id'])) {
    header("Location: data_produk.php");
    exit;
}

$id_produk = (int)$_GET['id'];

// Get data produk
$produk_query = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk = $id_produk");
if (mysqli_num_rows($produk_query) == 0) {
    header("Location: data_produk.php");
    exit;
}
$produk = mysqli_fetch_assoc($produk_query);

// Get kategori & supplier untuk dropdown
$kategori_list = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
$supplier_list = mysqli_query($conn, "SELECT * FROM suppliers ORDER BY nama_supplier ASC");

// PROSES UPDATE PRODUK
if (isset($_POST['update'])) {
    $nama_produk = mysqli_real_escape_string($conn, $_POST['nama_produk']);
    $harga = (int)$_POST['harga'];
    $stok = (int)$_POST['stok'];
    $id_kategori = $_POST['id_kategori'] != '' ? (int)$_POST['id_kategori'] : null;
    $id_supplier = $_POST['id_supplier'] != '' ? (int)$_POST['id_supplier'] : null;
    
    $gambar = $produk['gambar'];
    
    // Handle upload gambar baru
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['gambar']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $newname = uniqid() . '.' . $ext;
            $upload_path = 'uploads/' . $newname;
            
            if (!file_exists('uploads')) {
                mkdir('uploads', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $upload_path)) {
                if ($produk['gambar'] && file_exists('uploads/' . $produk['gambar'])) {
                    unlink('uploads/' . $produk['gambar']);
                }
                $gambar = $newname;
            }
        } else {
            $error = "Format file tidak didukung. Gunakan JPG, PNG, atau GIF.";
        }
    }
    
    if (empty($error)) {
        $kategori_val = $id_kategori ? $id_kategori : 'NULL';
        $supplier_val = $id_supplier ? $id_supplier : 'NULL';
        
        $query = "UPDATE produk SET 
                    nama_produk = '$nama_produk',
                    harga = $harga,
                    stok = $stok,
                    id_kategori = $kategori_val,
                    id_supplier = $supplier_val,
                    gambar = '$gambar'
                  WHERE id_produk = $id_produk";
        
        if (mysqli_query($conn, $query)) {
            $success = "Produk berhasil diperbarui!";
            $produk_query = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk = $id_produk");
            $produk = mysqli_fetch_assoc($produk_query);
        } else {
            $error = "Gagal memperbarui produk: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Produk - Reborn Garage</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

:root {
    --primary: #1e1e2f;
    --secondary: #2f2f45;
    --accent: #43a047;
    --success: #4caf50;
    --warning: #ff9800;
    --danger: #f44336;
    --info: #1e88e5;
    --light-bg: #f4f6f8;
}

body {
    background: var(--light-bg);
    overflow-x: hidden;
}

/* ========== SIDEBAR ========== */
.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: var(--primary);
    color: white;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1000;
    box-shadow: 4px 0 12px rgba(0,0,0,0.15);
    overflow-y: auto;
}

.sidebar.small {
    width: 70px;
}

.logo {
    padding: 25px 20px;
    text-align: center;
    font-weight: 700;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.logo-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid var(--accent);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.logo-image:hover {
    transform: scale(1.05);
}

.logo-text {
    color: white;
}

.sidebar.small .logo-text {
    display: none;
}

.sidebar.small .logo-image {
    width: 50px;
    height: 50px;
}

/* ========== USER INFO ========== */
.user-badge {
    padding: 15px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.badge-content {
    background: rgba(67, 160, 71, 0.2);
    border-left: 3px solid var(--accent);
    padding: 12px 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s;
}

.badge-icon {
    font-size: 18px;
    flex-shrink: 0;
}

.badge-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.sidebar.small .badge-text {
    display: none;
}

.sidebar.small .badge-content {
    justify-content: center;
    border-left: none;
    background: transparent;
    padding: 8px;
}

/* ========== MENU ========== */
.menu {
    margin-top: 30px;
    padding: 0 10px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 16px 20px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.2s;
    border-radius: 8px;
    margin-bottom: 8px;
}

.menu a:hover {
    background: var(--secondary);
    color: white;
    transform: translateX(5px);
}

.menu a.active {
    background: var(--accent);
    color: white;
}

.menu a .icon {
    font-size: 20px;
    min-width: 20px;
}

.sidebar.small .menu a span {
    display: none;
}

.toggle {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    cursor: pointer;
    font-size: 24px;
    transition: all 0.3s;
    padding: 10px;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
}

.toggle:hover {
    background: rgba(255,255,255,0.2);
    transform: translateX(-50%) scale(1.1);
}

/* ========== CONTENT ========== */
.content {
    margin-left: 250px;
    padding: 40px;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    min-height: 100vh;
}

.content.small {
    margin-left: 70px;
}

/* ========== HEADER ========== */
.page-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    margin-bottom: 40px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
}

.page-header h1 {
    font-size: 36px;
    margin-bottom: 8px;
    font-weight: 700;
}

.breadcrumb {
    font-size: 14px;
    opacity: 0.9;
}

.breadcrumb a {
    color: white;
    text-decoration: none;
    opacity: 0.8;
}

.breadcrumb a:hover {
    opacity: 1;
    text-decoration: underline;
}

/* ========== FORM CARD ========== */
.form-container {
    max-width: 800px;
}

.card {
    background: white;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
}

/* ========== ALERT ========== */
.alert {
    padding: 16px 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.alert-success {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    color: #1b5e20;
    border-left: 4px solid var(--success);
}

.alert-error {
    background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%);
    color: #b71c1c;
    border-left: 4px solid var(--danger);
}

/* ========== FORM ========== */
.form-group {
    margin-bottom: 25px;
}

label {
    display: block;
    font-weight: 600;
    font-size: 14px;
    color: var(--primary);
    margin-bottom: 8px;
}

label .required {
    color: var(--danger);
}

input[type="text"],
input[type="number"],
select {
    width: 100%;
    padding: 14px 16px;
    border-radius: 10px;
    border: 2px solid #e0e0e0;
    font-size: 15px;
    transition: all 0.3s;
    background: #fafafa;
}

input[type="text"]:focus,
input[type="number"]:focus,
select:focus {
    outline: none;
    border-color: var(--info);
    background: white;
    box-shadow: 0 4px 12px rgba(30,136,229,0.1);
}

select {
    cursor: pointer;
}

/* ========== CURRENCY INPUT STYLING ========== */
.currency-input {
    position: relative;
}

.currency-input::before {
    content: 'Rp';
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    font-weight: 600;
    color: var(--info);
    font-size: 15px;
    pointer-events: none;
}

.currency-input input {
    padding-left: 45px;
}

.hint-text {
    font-size: 12px;
    color: #666;
    margin-top: 6px;
    font-weight: 400;
}

/* ========== PRICE DISPLAY ========== */
.current-price {
    margin-top: 8px;
    padding: 10px 14px;
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
    border-left: 3px solid var(--info);
    border-radius: 8px;
    font-size: 14px;
    color: #0d47a1;
}

.current-price strong {
    font-weight: 700;
    font-size: 16px;
}

/* ========== IMAGE PREVIEW ========== */
.current-image {
    margin-top: 10px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.current-image img {
    max-width: 100px;
    max-height: 100px;
    border-radius: 8px;
    object-fit: cover;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.current-image .info {
    font-size: 13px;
    color: #666;
}

/* ========== FILE UPLOAD ========== */
.file-upload {
    position: relative;
    margin-top: 10px;
}

.file-label {
    display: block;
    padding: 14px 16px;
    background: #fafafa;
    border: 2px dashed #e0e0e0;
    border-radius: 10px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s;
}

.file-label:hover {
    border-color: var(--info);
    background: #e3f2fd;
}

.file-label .icon {
    font-size: 32px;
    display: block;
    margin-bottom: 8px;
}

input[type="file"] {
    position: absolute;
    opacity: 0;
    cursor: pointer;
}

.file-info {
    margin-top: 10px;
    font-size: 13px;
    color: #666;
}

/* ========== BUTTONS ========== */
.form-actions {
    display: flex;
    gap: 15px;
    margin-top: 30px;
}

.btn {
    padding: 14px 30px;
    border: none;
    border-radius: 10px;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
    text-align: center;
}

.btn-primary {
    background: linear-gradient(135deg, var(--info) 0%, #42a5f5 100%);
    color: white;
    box-shadow: 0 4px 15px rgba(30,136,229,0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #1565c0 0%, #1976d2 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(30,136,229,0.4);
}

.btn-secondary {
    background: #e0e0e0;
    color: #333;
}

.btn-secondary:hover {
    background: #d0d0d0;
    transform: translateY(-2px);
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .sidebar {
        width: 70px;
    }
    
    .sidebar .logo-text,
    .sidebar .menu a span,
    .sidebar .badge-text {
        display: none;
    }
    
    .sidebar .badge-content {
        justify-content: center;
        border-left: none;
        background: transparent;
    }
    
    .content {
        margin-left: 70px;
        padding: 20px;
    }
    
    .page-header h1 {
        font-size: 28px;
    }
    
    .card {
        padding: 25px 20px;
    }
    
    .form-actions {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
    }
}
</style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="logo">
        <img src="assets/logo.jpg" alt="Reborn Garage Logo" class="logo-image">
        <span class="logo-text">Reborn Garage</span>
    </div>
    
    <!-- USER INFO -->
    <div class="user-badge">
        <div class="badge-content">
            <span class="badge-icon">👤</span>
            <span class="badge-text"><?= htmlspecialchars($nama_user); ?></span>
        </div>
    </div>
    
    <div class="menu">
        <a href="dashboard_staff.php">
            <span class="icon">🏠</span>
            <span>Dashboard</span>
        </a>
        <a href="data_produk.php" class="active">
            <span class="icon">📦</span>
            <span>Kelola Produk</span>
        </a>
        <a href="kategori.php">
            <span class="icon">🏷️</span>
            <span>Kategori</span>
        </a>
        <a href="supplier.php">
            <span class="icon">🏭</span>
            <span>Supplier</span>
        </a>
        <a href="barang_masuk.php">
            <span class="icon">📥</span>
            <span>Barang Masuk</span>
        </a>
        <a href="barang_keluar.php">
            <span class="icon">📤</span>
            <span>Barang Keluar</span>
        </a>
        <a href="kelola_pesanan.php">
            <span class="icon">📋</span>
            <span>Kelola Pesanan</span>
        </a>
        <a href="logout.php">
            <span class="icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>
    <div class="toggle" onclick="toggleSidebar()" title="Toggle Sidebar">⬅️</div>
</div>

<div class="content" id="content">
    <div class="page-header">
        <h1>✏️ Edit Produk</h1>
        <div class="breadcrumb">
            <a href="dashboard_staff.php">Dashboard</a> / 
            <a href="data_produk.php">Data Produk</a> / 
            Edit Produk
        </div>
    </div>

    <div class="form-container">
        <div class="card">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <span>✅</span>
                    <span><?= $success; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <span>❌</span>
                    <span><?= $error; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>
                        📝 Nama Produk 
                        <span class="required">*</span>
                    </label>
                    <input 
                        type="text" 
                        name="nama_produk" 
                        required
                        value="<?= htmlspecialchars($produk['nama_produk']); ?>"
                    >
                </div>

                <div class="form-group">
                    <label>
                        💰 Harga Produk 
                        <span class="required">*</span>
                    </label>
                    <div class="current-price">
                        💵 Harga Saat Ini: <strong>Rp <?= number_format($produk['harga'], 0, ',', '.'); ?></strong>
                    </div>
                    <div class="currency-input">
                        <input 
                            type="number" 
                            name="harga" 
                            placeholder="<?= $produk['harga']; ?>"
                            min="0"
                            step="1000"
                            required
                            value="<?= $produk['harga']; ?>"
                        >
                    </div>
                    <div class="hint-text">Masukkan harga baru dalam Rupiah (tanpa titik atau koma)</div>
                </div>

                <div class="form-group">
                    <label>
                        📊 Stok 
                        <span class="required">*</span>
                    </label>
                    <input 
                        type="number" 
                        name="stok" 
                        min="0"
                        required
                        value="<?= $produk['stok']; ?>"
                    >
                </div>

                <div class="form-group">
                    <label>🏷️ Kategori</label>
                    <select name="id_kategori">
                        <option value="">-- Pilih Kategori (Opsional) --</option>
                        <?php while($k = mysqli_fetch_assoc($kategori_list)): ?>
                            <option value="<?= $k['id_kategori']; ?>" 
                                <?= $produk['id_kategori'] == $k['id_kategori'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($k['nama_kategori']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>🏭 Supplier</label>
                    <select name="id_supplier">
                        <option value="">-- Pilih Supplier (Opsional) --</option>
                        <?php while($s = mysqli_fetch_assoc($supplier_list)): ?>
                            <option value="<?= $s['id_supplier']; ?>"
                                <?= $produk['id_supplier'] == $s['id_supplier'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($s['nama_supplier']); ?> - <?= htmlspecialchars($s['asal']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>🖼️ Gambar Produk</label>
                    
                    <?php if ($produk['gambar']): ?>
                        <div class="current-image">
                            <img src="uploads/<?= htmlspecialchars($produk['gambar']); ?>" 
                                 alt="Current Image">
                            <div class="info">
                                <strong>Gambar Saat Ini</strong><br>
                                <?= htmlspecialchars($produk['gambar']); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="file-upload">
                        <label for="gambar" class="file-label">
                            <span class="icon">📷</span>
                            <span id="file-name">Klik untuk upload gambar baru (opsional)</span>
                        </label>
                        <input 
                            type="file" 
                            name="gambar" 
                            id="gambar"
                            accept="image/*"
                            onchange="updateFileName(this)"
                        >
                    </div>
                    <div class="file-info">
                        Format: JPG, PNG, GIF. Kosongkan jika tidak ingin mengubah gambar.
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" name="update" class="btn btn-primary">
                        💾 Update Produk
                    </button>
                    <a href="data_produk.php" class="btn btn-secondary">
                        ❌ Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const toggle = document.querySelector('.toggle');
    
    sidebar.classList.toggle('small');
    content.classList.toggle('small');
    
    toggle.style.transform = 'translateX(-50%) rotate(180deg)';
    setTimeout(() => {
        toggle.textContent = sidebar.classList.contains('small') ? '➡️' : '⬅️';
        toggle.style.transform = 'translateX(-50%) rotate(0deg)';
    }, 150);
}

function updateFileName(input) {
    const fileName = input.files[0]?.name || 'Klik untuk upload gambar baru (opsional)';
    document.getElementById('file-name').textContent = fileName;
}

// Smooth page load
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.3s';
        document.body.style.opacity = '1';
    }, 100);
});

// Auto-hide success message
<?php if ($success): ?>
setTimeout(() => {
    const alert = document.querySelector('.alert-success');
    if (alert) {
        alert.style.transition = 'all 0.3s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }
}, 3000);
<?php endif; ?>
</script>
</body>
</html>