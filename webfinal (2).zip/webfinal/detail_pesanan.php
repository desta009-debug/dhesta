<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    echo '<p style="color: red;">Unauthorized access</p>';
    exit;
}

if (!isset($_GET['id'])) {
    echo '<p style="color: red;">Invalid order ID</p>';
    exit;
}

$id_order = (int)$_GET['id'];

// Get order details
$order_query = "
    SELECT o.*, u.nama, u.email 
    FROM orders o 
    LEFT JOIN users u ON o.id_user = u.id_user 
    WHERE o.id_order = $id_order
";
$order_result = mysqli_query($conn, $order_query);

if (!$order_result || mysqli_num_rows($order_result) == 0) {
    echo '<p style="color: red;">Pesanan tidak ditemukan</p>';
    exit;
}

$order = mysqli_fetch_assoc($order_result);

// Get order items
$items_query = "
    SELECT oi.*, p.nama_produk, p.gambar 
    FROM order_items oi 
    LEFT JOIN produk p ON oi.id_produk = p.id_produk 
    WHERE oi.id_order = $id_order
";
$items_result = mysqli_query($conn, $items_query);

// Payment method labels
$payment_labels = [
    'cash' => '💵 Cash',
    'transfer_bank' => '🏦 Transfer Bank',
    'e_wallet' => '📱 E-Wallet',
    'cicilan' => '💳 Cicilan'
];

// Status labels
$status_labels = [
    'pending' => '⏳ Menunggu',
    'completed' => '✓ Selesai',
    'cancelled' => '✖ Dibatalkan'
];
?>

<div class="order-info">
    <div class="info-row">
        <div class="info-label">📋 ID Pesanan:</div>
        <div class="info-value"><strong>#<?= $order['id_order'] ?></strong></div>
    </div>
    <div class="info-row">
        <div class="info-label">👤 Nama Pelanggan:</div>
        <div class="info-value"><?= htmlspecialchars($order['nama'] ?? 'Guest') ?></div>
    </div>
    <div class="info-row">
        <div class="info-label">📧 Email:</div>
        <div class="info-value"><?= htmlspecialchars($order['email'] ?? '-') ?></div>
    </div>
    <div class="info-row">
        <div class="info-label">💰 Total Harga:</div>
        <div class="info-value"><strong style="color: #9c27b0; font-size: 18px;">Rp <?= number_format($order['total_harga'], 0, ',', '.') ?></strong></div>
    </div>
    <div class="info-row">
        <div class="info-label">💳 Metode Pembayaran:</div>
        <div class="info-value"><?= $payment_labels[$order['metode_pembayaran']] ?? $order['metode_pembayaran'] ?></div>
    </div>
    <?php if (!empty($order['alamat_pengiriman'])): ?>
    <div class="info-row">
        <div class="info-label">📍 Alamat Pengiriman:</div>
        <div class="info-value"><?= nl2br(htmlspecialchars($order['alamat_pengiriman'])) ?></div>
    </div>
    <?php endif; ?>
    <?php if (!empty($order['nomor_telepon'])): ?>
    <div class="info-row">
        <div class="info-label">📱 Nomor Telepon:</div>
        <div class="info-value"><?= htmlspecialchars($order['nomor_telepon']) ?></div>
    </div>
    <?php endif; ?>
    <?php if (!empty($order['catatan'])): ?>
    <div class="info-row">
        <div class="info-label">📝 Catatan:</div>
        <div class="info-value"><?= nl2br(htmlspecialchars($order['catatan'])) ?></div>
    </div>
    <?php endif; ?>
    <div class="info-row">
        <div class="info-label">📅 Tanggal Pesanan:</div>
        <div class="info-value"><?= date('d F Y, H:i', strtotime($order['tanggal_order'])) ?> WIB</div>
    </div>
    <div class="info-row">
        <div class="info-label">📊 Status:</div>
        <div class="info-value">
            <span class="status-badge status-<?= $order['status'] ?>">
                <?= $status_labels[$order['status']] ?? $order['status'] ?>
            </span>
        </div>
    </div>
</div>

<div class="items-table">
    <h3>🛒 Item Pesanan</h3>
    <table style="margin-top: 15px;">
        <thead>
            <tr>
                <th style="width: 80px;">Gambar</th>
                <th>Produk</th>
                <th style="width: 120px; text-align: center;">Jumlah</th>
                <th style="width: 150px;">Harga Satuan</th>
                <th style="width: 150px;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = mysqli_fetch_assoc($items_result)): ?>
                <tr>
                    <td>
                        <?php if (!empty($item['gambar'])): ?>
                            <img src="uploads/<?= htmlspecialchars($item['gambar']) ?>" 
                                 alt="<?= htmlspecialchars($item['nama_produk']) ?>" 
                                 style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px;">
                        <?php else: ?>
                            <div style="width: 50px; height: 50px; background: #f0f0f0; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 24px;">📦</div>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= htmlspecialchars($item['nama_produk'] ?? 'Produk Tidak Diketahui') ?></strong></td>
                    <td style="text-align: center;">
                        <span style="background: linear-gradient(135deg, #4caf50, #66bb6a); color: white; padding: 6px 12px; border-radius: 6px; font-weight: 700;">
                            <?= $item['jumlah'] ?>x
                        </span>
                    </td>
                    <td>Rp <?= number_format($item['harga_satuan'], 0, ',', '.') ?></td>
                    <td><strong style="color: #9c27b0;">Rp <?= number_format($item['subtotal'], 0, ',', '.') ?></strong></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr style="background: #f5f5f5; font-weight: 700;">
                <td colspan="4" style="text-align: right; padding: 15px;">TOTAL:</td>
                <td style="padding: 15px;">
                    <span style="color: #9c27b0; font-size: 18px;">Rp <?= number_format($order['total_harga'], 0, ',', '.') ?></span>
                </td>
            </tr>
        </tfoot>
    </table>
</div>

<form method="POST" action="kelola_pesanan.php">
    <input type="hidden" name="id_order" value="<?= $order['id_order'] ?>">
    
    <div class="form-group">
        <label>📊 Update Status Pesanan:</label>
        <select name="status" required>
            <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>⏳ Menunggu</option>
            <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>✓ Selesai</option>
            <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>✖ Dibatalkan</option>
        </select>
    </div>
    
    <div class="modal-actions">
        <button type="submit" name="update_status" class="btn btn-primary">
            💾 Simpan Perubahan
        </button>
        <button type="button" class="btn btn-secondary" onclick="closeModal()">
            ❌ Tutup
        </button>
    </div>
</form>