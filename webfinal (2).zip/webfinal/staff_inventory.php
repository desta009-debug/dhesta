<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {
    header("Location: index.php");
    exit;
}

$conn = mysqli_connect("localhost", "root", "", "reborn");
if (!$conn) {
    die("Database error");
}

/* ========== TAMBAH DATA ========== */
if (isset($_POST['tambah'])) {
    mysqli_query($conn, "INSERT INTO barang VALUES(
        NULL,
        '$_POST[nama]',
        '$_POST[stok]',
        '$_POST[harga]'
    )");
}

/* ========== HAPUS DATA ========== */
if (isset($_GET['hapus'])) {
    mysqli_query($conn, "DELETE FROM barang WHERE id_barang='$_GET[hapus]'");
}

/* ========== EDIT DATA ========== */
if (isset($_POST['update'])) {
    mysqli_query($conn, "UPDATE barang SET
        nama_barang='$_POST[nama]',
        stok='$_POST[stok]',
        harga='$_POST[harga]'
        WHERE id_barang='$_POST[id]'
    ");
}

/* ========== DATA BARANG ========== */
$data = mysqli_query($conn, "SELECT * FROM barang");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inventory Staff | Reborn Garage</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; padding:20px; }
        h2 { margin-bottom:10px; }
        table { width:100%; border-collapse:collapse; background:#fff; }
        th, td { padding:10px; border:1px solid #ddd; text-align:center; }
        th { background:#000; color:#fff; }
        form { background:#fff; padding:15px; margin-bottom:20px; }
        input { padding:8px; margin-right:5px; }
        button { padding:8px 15px; background:#000; color:#fff; border:none; }
        a { text-decoration:none; color:red; }
    </style>
</head>
<body>

<h2>Inventory Barang - Staff</h2>
<p>Login sebagai: <b><?= $_SESSION['nama']; ?></b> | <a href="logout.php">Logout</a></p>

<!-- FORM TAMBAH -->
<form method="POST">
    <input type="text" name="nama" placeholder="Nama Barang" required>
    <input type="number" name="stok" placeholder="Stok" required>
    <input type="number" name="harga" placeholder="Harga" required>
    <button name="tambah">Tambah</button>
</form>

<!-- TABEL DATA -->
<table>
    <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Stok</th>
        <th>Harga</th>
        <th>Aksi</th>
    </tr>

<?php
$no = 1;
while ($row = mysqli_fetch_assoc($data)) {
?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama_barang']; ?></td>
    <td><?= $row['stok']; ?></td>
    <td>Rp <?= number_format($row['harga']); ?></td>
    <td>
        <a href="?hapus=<?= $row['id_barang']; ?>" onclick="return confirm('Hapus?')">Hapus</a>
    </td>
</tr>
<?php } ?>
</table>

</body>
</html>
